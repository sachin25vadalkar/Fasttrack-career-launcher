import React, { useState, useMemo, useEffect, useRef } from 'react';
import { 
  GraduationCap, 
  Search, 
  Award, 
  TrendingUp, 
  Globe, 
  DollarSign, 
  CheckCircle2, 
  AlertCircle, 
  Sparkles, 
  BookOpen, 
  ArrowRight, 
  ChevronRight, 
  Briefcase, 
  Layers, 
  Compass, 
  UserCheck, 
  RefreshCw, 
  Globe2, 
  MapPin, 
  Info,
  CheckCircle,
  HelpCircle,
  FileText
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { qualificationsData, QualificationData, CareerPath, SkillItem } from './data/careersData';
import { indianMarketScopeData } from './data/indianMarketData';
import ReactMarkdown from 'react-markdown';

export default function App() {
  // Navigation & filter state
  const [activeCategory, setActiveCategory] = useState<'All' | 'Commerce' | 'Science' | 'Engineering' | 'Diploma'>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [showDropdown, setShowDropdown] = useState(false);
  const searchContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (searchContainerRef.current && !searchContainerRef.current.contains(event.target as Node)) {
        setShowDropdown(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  // Selection states
  const [selectedQualId, setSelectedQualId] = useState('be-btech');
  const [selectedPathId, setSelectedPathId] = useState('cloud-devops');

  // Interactive user checklist state: mapping (careerPathId_skillName) -> boolean
  const [acquiredSkills, setAcquiredSkills] = useState<Record<string, boolean>>(() => {
    // Default pre-checked states for some standard skills to make it look realistic on load
    return {
      'cloud-devops_Linux System Administration': true,
      'cloud-devops_Git & GitHub Workflows': true,
      'software-dev-bsc_JavaScript / TypeScript': true,
      'software-dev-bsc_Git & GitHub Workflows': true,
      'corp-accounting_Advanced MS Excel': true
    };
  });

  // User details for AI report
  const [experienceNotes, setExperienceNotes] = useState('');
  const [additionalGoals, setAdditionalGoals] = useState('');
  
  // AI Response states
  const [aiReport, setAiReport] = useState<string | null>(null);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);
  const [showAIModal, setShowAIModal] = useState(false);

  // Filtered qualifications based on category & search query
  const filteredQualifications = useMemo(() => {
    return qualificationsData.filter(q => {
      const matchesCategory = activeCategory === 'All' || q.category === activeCategory;
      const matchesSearch = q.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            q.fullForm.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            q.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            q.commonSpecializations.some(s => s.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchesCategory && matchesSearch;
    });
  }, [activeCategory, searchQuery]);

  // Current selected qualification
  const currentQualification = useMemo(() => {
    return qualificationsData.find(q => q.id === selectedQualId) || qualificationsData[0];
  }, [selectedQualId]);

  // Current selected career path
  const currentPath = useMemo(() => {
    if (!currentQualification) return null;
    return currentQualification.careerPaths.find(p => p.id === selectedPathId) || currentQualification.careerPaths[0];
  }, [currentQualification, selectedPathId]);

  // Reset selected path when qualification changes
  useEffect(() => {
    if (currentQualification && currentQualification.careerPaths.length > 0) {
      // Find if the path is actually in the qualification
      const hasPath = currentQualification.careerPaths.some(p => p.id === selectedPathId);
      if (!hasPath) {
        setSelectedPathId(currentQualification.careerPaths[0].id);
      }
    }
  }, [currentQualification, selectedPathId]);

  // Handle toggling of a skill
  const toggleSkill = (pathId: string, skillName: string) => {
    const key = `${pathId}_${skillName}`;
    setAcquiredSkills(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  // Calculate readiness percentage for current path
  const readinessMetrics = useMemo(() => {
    if (!currentPath) return { percent: 0, acquired: 0, total: 0 };
    const pathSkills = currentPath.skillsMatrix;
    const total = pathSkills.length;
    let acquired = 0;
    pathSkills.forEach(s => {
      if (acquiredSkills[`${currentPath.id}_${s.name}`]) {
        acquired++;
      }
    });
    const percent = total > 0 ? Math.round((acquired / total) * 100) : 0;
    return { percent, acquired, total };
  }, [currentPath, acquiredSkills]);

  // Trigger full-stack AI advisor report call
  const generateAIReport = async () => {
    if (!currentPath || !currentQualification) return;
    
    setAiLoading(true);
    setAiError(null);
    setAiReport(null);
    setShowAIModal(true);

    const pathSkills = currentPath.skillsMatrix;
    const skillsIHave: string[] = [];
    const skillsINeed: string[] = [];

    pathSkills.forEach(s => {
      const key = `${currentPath.id}_${s.name}`;
      if (acquiredSkills[key]) {
        skillsIHave.push(`${s.name} (${s.category})`);
      } else {
        skillsINeed.push(`${s.name} (${s.category})`);
      }
    });

    try {
      const response = await fetch('/api/advisory-report', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          qualification: currentQualification.name,
          category: currentQualification.category,
          fullForm: currentQualification.fullForm,
          careerPathTitle: currentPath.title,
          currentSkills: skillsIHave,
          skillGaps: skillsINeed,
          experienceNotes,
          additionalGoals
        })
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.details || errData.error || 'Server error generating report.');
      }

      const data = await response.json();
      setAiReport(data.report);
    } catch (err: any) {
      console.error(err);
      setAiError(err.message || 'Could not reach the AI Advisor Service. Verify your GEMINI_API_KEY is configured in the Secrets panel.');
    } finally {
      setAiLoading(false);
    }
  };

  // Mock global hot jobs data for sidebar
  const trendingGlobalJobs = [
    { title: 'SRE / DevOps Lead', location: 'Munich, Germany', visa: 'Highly open', demand: 'Explosive', pay: '€85K - €110K', match: 'B.E. / B.Tech (CS/ECE)' },
    { title: 'Global Wealth Consultant', location: 'Singapore Hub', visa: 'Tier-1 open', demand: 'High', pay: 'SGD 110K - 140K', match: 'B.Com / M.Com + CFA' },
    { title: 'Embedded Systems Specialist', location: 'Hsinchu, Taiwan', visa: 'Tech visa sponsored', demand: 'Very High', pay: 'TWD 1.8M - 2.4M', match: 'Diploma / B.Tech (ECE)' },
    { title: 'AI Research Scientist', location: 'San Francisco, USA', visa: 'O-1 / H1-B Cap-Exempt', demand: 'Explosive', pay: '$140K - $190K', match: 'M.E. / M.Tech + AI/ML' },
    { title: 'Pharma Quality Auditor', location: 'Basel, Switzerland', visa: 'Corporate Transfer', demand: 'Stable', pay: 'CHF 90K - 115K', match: 'B.Sc. / M.Sc. (Biotech/Chem)' }
  ];

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-800 selection:bg-indigo-100 selection:text-indigo-900 font-sans">
      {/* Decorative top ambient bar */}
      <div className="h-1.5 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 w-full" />

      {/* Top Navigation */}
      <header id="header" className="sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b border-slate-200/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-gradient-to-br from-indigo-600 to-indigo-700 rounded-xl text-white shadow-md shadow-indigo-100 flex items-center justify-center">
              <GraduationCap className="w-6 h-6" />
            </div>
            <div>
              <span className="font-extrabold text-xl tracking-tight text-slate-900 font-display flex items-center gap-1.5">
                Fasttrack <span className="text-indigo-600 font-normal">Career Launchers</span>
              </span>
              <p className="text-[10px] text-slate-500 tracking-wider font-mono uppercase">Indian Education Global Matcher</p>
            </div>
          </div>

          {/* Quick Metrics */}
          <div className="hidden md:flex items-center gap-6 text-xs font-medium text-slate-600">
            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-50 text-indigo-700 rounded-full">
              <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-pulse" />
              <span className="font-mono">7+ Indian degrees</span>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 text-emerald-700 rounded-full">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="font-mono">14 Global Tracks</span>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section id="hero-section" className="relative py-12 lg:py-16 overflow-hidden bg-white border-b border-slate-200">
        {/* Background decorative grids */}
        <div className="absolute inset-0 opacity-40 pointer-events-none">
          <div className="absolute -top-48 -right-48 w-96 h-96 bg-purple-100 rounded-full blur-3xl" />
          <div className="absolute top-24 -left-48 w-96 h-96 bg-indigo-100 rounded-full blur-3xl" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-indigo-50 text-indigo-700 rounded-full text-xs font-semibold mb-4 tracking-wide uppercase">
              <Sparkles className="w-3.5 h-3.5 text-indigo-500" /> Bridging Academics & Employment
            </span>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-slate-950 font-display max-w-4xl mx-auto leading-[1.1]">
              Launch Your Global Career from <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600">Indian Qualifications</span>
            </h1>
            <p className="mt-4 text-base sm:text-lg text-slate-600 max-w-2xl mx-auto leading-relaxed">
              Instantly identify professional pathways for B.Com, M.Com, B.Sc, M.Sc, Engineering degrees, or Diplomas. Match with global industries, track skill gaps, and get personalized action plans.
            </p>
          </motion.div>

          {/* Quick search & filter bar */}
          <div className="mt-8 max-w-xl mx-auto relative" ref={searchContainerRef}>
            <div className="relative rounded-2xl shadow-md border border-slate-200 bg-white p-1 flex items-center focus-within:ring-2 focus-within:ring-indigo-500/20 focus-within:border-indigo-500 transition-all">
              <Search className="w-5 h-5 text-slate-400 ml-3" />
              <input
                type="text"
                value={searchQuery}
                onFocus={() => setShowDropdown(true)}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setShowDropdown(true);
                }}
                placeholder="Search qualification (e.g. CA, CS, MBBS, MD, PhD, B.Tech, M.Sc)..."
                className="w-full bg-transparent pl-2 pr-4 py-2.5 text-slate-800 placeholder-slate-400 focus:outline-none text-sm font-medium"
              />
              {searchQuery && (
                <button 
                  onClick={() => {
                    setSearchQuery('');
                    setShowDropdown(false);
                  }}
                  className="text-xs text-slate-400 hover:text-slate-600 font-semibold px-2.5 transition-colors"
                >
                  Clear
                </button>
              )}
            </div>

            {/* Autocomplete Dropdown overlay */}
            {showDropdown && (
              <div className="absolute left-0 right-0 mt-2 bg-white rounded-2xl border border-slate-200 shadow-xl z-50 max-h-80 overflow-y-auto p-2">
                <div className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400 border-b border-slate-100 flex items-center justify-between">
                  <span>Interactive Degree Finder</span>
                  <span>{qualificationsData.length} Degrees Available</span>
                </div>
                <div className="mt-1 space-y-0.5">
                  {qualificationsData
                    .filter(qual => {
                      if (!searchQuery) return true;
                      const q = searchQuery.toLowerCase();
                      return qual.name.toLowerCase().includes(q) ||
                             qual.fullForm.toLowerCase().includes(q) ||
                             qual.category.toLowerCase().includes(q) ||
                             qual.description.toLowerCase().includes(q);
                    })
                    .map(qual => {
                      const isSelected = selectedQualId === qual.id;
                      return (
                        <button
                          key={qual.id}
                          onClick={() => {
                            setSelectedQualId(qual.id);
                            setSearchQuery(qual.name);
                            setActiveCategory('All');
                            if (qual.careerPaths.length > 0) {
                              setSelectedPathId(qual.careerPaths[0].id);
                            }
                            setShowDropdown(false);
                          }}
                          className={`w-full text-left p-2.5 rounded-xl transition-all flex items-center justify-between gap-3 ${
                            isSelected 
                              ? 'bg-indigo-50/80 text-indigo-950 font-semibold border-l-4 border-indigo-600' 
                              : 'hover:bg-slate-50 text-slate-700'
                          }`}
                        >
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-bold text-slate-900">{qual.name}</span>
                              <span className="text-xs text-slate-400 truncate">({qual.fullForm})</span>
                            </div>
                            <p className="text-xs text-slate-500 line-clamp-1 mt-0.5">{qual.description}</p>
                          </div>
                          <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider font-mono ${
                            qual.category === 'Commerce' ? 'bg-amber-50 text-amber-700 border border-amber-100' :
                            qual.category === 'Science' ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' :
                            qual.category === 'Engineering' ? 'bg-indigo-50 text-indigo-700 border border-indigo-100' :
                            'bg-purple-50 text-purple-700 border border-purple-100'
                          }`}>
                            {qual.category}
                          </span>
                        </button>
                      );
                    })}
                  {qualificationsData.filter(qual => {
                    const q = searchQuery.toLowerCase();
                    return qual.name.toLowerCase().includes(q) ||
                           qual.fullForm.toLowerCase().includes(q) ||
                           qual.category.toLowerCase().includes(q) ||
                           qual.description.toLowerCase().includes(q);
                  }).length === 0 && (
                    <div className="p-4 text-center text-sm text-slate-400">
                      No matching educational qualifications found.
                    </div>
                  )}
                </div>
              </div>
            )}
            
            {/* Quick Suggestions - lists all available degrees */}
            <div className="mt-4">
              <p className="text-xs font-semibold text-slate-500 mb-2">Select any degree directly on the website:</p>
              <div className="flex items-center justify-center gap-1.5 flex-wrap max-w-2xl mx-auto">
                {qualificationsData.map(qual => {
                  const isCurrent = selectedQualId === qual.id;
                  return (
                    <button
                      key={qual.id}
                      onClick={() => {
                        setSelectedQualId(qual.id);
                        setSearchQuery(qual.name);
                        setActiveCategory('All');
                        if (qual.careerPaths.length > 0) {
                          setSelectedPathId(qual.careerPaths[0].id);
                        }
                      }}
                      className={`px-2.5 py-1 text-xs font-medium rounded-full border transition-all flex items-center gap-1 ${
                        isCurrent 
                          ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                          : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-700 shadow-sm'
                      }`}
                    >
                      <span>{qual.name}</span>
                      <span className={`text-[9px] uppercase font-mono tracking-tight opacity-75`}>
                        ({qual.category[0]})
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content Area: Career Navigation Hub */}
      <main id="main-hub" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        
        {/* Stream Filter Tabs */}
        <div className="flex justify-center mb-8">
          <div className="inline-flex p-1 bg-slate-200/80 backdrop-blur rounded-2xl border border-slate-300/40">
            {(['All', 'Commerce', 'Science', 'Engineering', 'Diploma'] as const).map((cat) => (
              <button
                key={cat}
                onClick={() => {
                  setActiveCategory(cat);
                  // Auto-select first in filtered list if not already
                  const match = qualificationsData.find(q => cat === 'All' || q.category === cat);
                  if (match) setSelectedQualId(match.id);
                }}
                className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
                  activeCategory === cat 
                    ? 'bg-white text-slate-950 shadow-sm' 
                    : 'text-slate-600 hover:text-slate-900 hover:bg-white/40'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Outer Bento Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column (Span 4): Qualifications List */}
          <div className="lg:col-span-4 bg-white rounded-2xl border border-slate-200 shadow-sm p-5 h-auto lg:sticky lg:top-20 max-h-[80vh] overflow-y-auto">
            <div className="flex items-center gap-2 mb-4 pb-2 border-b border-slate-100">
              <Briefcase className="w-5 h-5 text-indigo-600" />
              <h2 className="font-bold text-base text-slate-900 font-display">Indian Qualifications ({filteredQualifications.length})</h2>
            </div>
            
            {filteredQualifications.length === 0 ? (
              <div className="text-center py-10">
                <AlertCircle className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                <p className="text-sm font-medium text-slate-500">No qualifications match your search query.</p>
                <button 
                  onClick={() => { setSearchQuery(''); setActiveCategory('All'); }}
                  className="mt-3 text-xs text-indigo-600 hover:underline font-semibold"
                >
                  Reset filters
                </button>
              </div>
            ) : (
              <div className="space-y-2.5">
                {filteredQualifications.map((qual) => {
                  const isSelected = selectedQualId === qual.id;
                  return (
                    <button
                      key={qual.id}
                      onClick={() => {
                        setSelectedQualId(qual.id);
                        if (qual.careerPaths.length > 0) {
                          setSelectedPathId(qual.careerPaths[0].id);
                        }
                      }}
                      className={`w-full text-left p-3.5 rounded-xl transition-all border ${
                        isSelected 
                          ? 'bg-indigo-50/70 border-indigo-200 shadow-sm shadow-indigo-50' 
                          : 'bg-white border-slate-100 hover:bg-slate-50/80 hover:border-slate-200'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className={`font-bold text-sm ${isSelected ? 'text-indigo-950' : 'text-slate-900'}`}>
                              {qual.name}
                            </h3>
                            <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                              qual.category === 'Engineering' ? 'bg-amber-100 text-amber-800' :
                              qual.category === 'Commerce' ? 'bg-emerald-100 text-emerald-800' :
                              qual.category === 'Science' ? 'bg-blue-100 text-blue-800' :
                              'bg-purple-100 text-purple-800'
                            }`}>
                              {qual.category}
                            </span>
                          </div>
                          <p className="text-xs text-slate-500 mt-0.5 font-medium line-clamp-1">
                            {qual.fullForm}
                          </p>
                        </div>
                        <ChevronRight className={`w-4 h-4 mt-0.5 transition-transform ${isSelected ? 'text-indigo-600 translate-x-1' : 'text-slate-300'}`} />
                      </div>
                      
                      {/* Active Preview */}
                      {isSelected && (
                        <div className="mt-3 pt-3 border-t border-indigo-100/60 text-[11px] text-slate-600">
                          <span className="font-semibold block mb-1 text-indigo-900">Career tracks available:</span>
                          <div className="flex flex-wrap gap-1">
                            {qual.careerPaths.map(p => (
                              <span key={p.id} className="px-1.5 py-0.5 bg-indigo-100/40 text-indigo-800 rounded font-medium">
                                {p.title}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            )}

            {/* Indian System Context note */}
            <div className="mt-6 p-3 bg-slate-50 rounded-xl border border-slate-100 flex gap-2 items-start text-xs text-slate-500">
              <Info className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-slate-700">Indian System Alignments</span>
                <p className="mt-0.5 leading-relaxed">Matches UGC, AICTE, and State Board curriculums to global enterprise roles directly.</p>
              </div>
            </div>
          </div>

          {/* Right Column (Span 8): Career Explorer & Tools */}
          <div className="lg:col-span-8 space-y-8">
            
            {/* Degree Summary Card */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5">
                <div>
                  <span className="text-xs font-semibold text-indigo-600 tracking-wider uppercase font-mono">{currentQualification.category} STREAM</span>
                  <h2 className="text-2xl font-black text-slate-900 mt-1 font-display">
                    {currentQualification.fullForm} ({currentQualification.name})
                  </h2>
                </div>
                <div className="flex items-center gap-1.5 text-xs text-slate-500 bg-slate-100 px-3 py-1.5 rounded-lg shrink-0">
                  <Layers className="w-4 h-4 text-slate-400" />
                  <span className="font-mono">Specializations Mapped</span>
                </div>
              </div>

              <p className="text-sm text-slate-600 mt-4 leading-relaxed">
                {currentQualification.description}
              </p>

              <div className="mt-4">
                <span className="text-xs font-semibold text-slate-500 block mb-2 uppercase tracking-wide">Common Indian Specializations Covered:</span>
                <div className="flex flex-wrap gap-1.5">
                  {currentQualification.commonSpecializations.map((spec, idx) => (
                    <span key={idx} className="text-xs bg-slate-100 text-slate-700 px-2.5 py-1 rounded-lg border border-slate-200/50 font-medium">
                      {spec}
                    </span>
                  ))}
                </div>
              </div>

              {/* Path Switcher inside active Qualification */}
              <div className="mt-6 pt-5 border-t border-slate-100">
                <span className="text-xs font-bold text-slate-700 block mb-3 uppercase tracking-wider">Select Mapped Career Path:</span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {currentQualification.careerPaths.map((path) => {
                    const isSelectedPath = selectedPathId === path.id;
                    return (
                      <button
                        key={path.id}
                        onClick={() => setSelectedPathId(path.id)}
                        className={`p-3.5 rounded-xl border text-left transition-all ${
                          isSelectedPath 
                            ? 'bg-slate-900 border-slate-900 text-white shadow-md' 
                            : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-800'
                        }`}
                      >
                        <div className="flex items-start gap-2.5">
                          <Compass className={`w-4 h-4 shrink-0 mt-0.5 ${isSelectedPath ? 'text-indigo-400' : 'text-slate-400'}`} />
                          <div>
                            <h4 className="font-bold text-xs leading-tight">{path.title}</h4>
                            <p className={`text-[10px] mt-1 line-clamp-1 ${isSelectedPath ? 'text-slate-300' : 'text-slate-500'}`}>
                              {path.description}
                            </p>
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Active Path Insights Grid */}
            {currentPath && (
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentPath.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-8"
                >
                  
                  {/* Global Market Demand & Salary Benchmarking */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    
                    {/* Market Demand Stats */}
                    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 flex flex-col justify-between">
                      <div>
                        <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
                          <h3 className="font-bold text-sm text-slate-900 uppercase tracking-wider flex items-center gap-1.5 font-display">
                            <TrendingUp className="w-4 h-4 text-emerald-500" /> Global Demand Outlook
                          </h3>
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold tracking-wide uppercase ${
                            currentPath.globalDemand.outlook === 'Explosive' ? 'bg-red-100 text-red-700 animate-pulse' :
                            currentPath.globalDemand.outlook === 'Very High' ? 'bg-amber-100 text-amber-700' :
                            currentPath.globalDemand.outlook === 'High' ? 'bg-emerald-100 text-emerald-700' :
                            'bg-blue-100 text-blue-700'
                          }`}>
                            {currentPath.globalDemand.outlook}
                          </span>
                        </div>

                        <div className="space-y-3.5">
                          <div>
                            <span className="text-[11px] text-slate-400 block uppercase font-mono">Top Hiring Countries</span>
                            <div className="flex flex-wrap gap-1 mt-1">
                              {currentPath.globalDemand.countries.map((c, i) => (
                                <span key={i} className="text-xs bg-slate-50 text-slate-700 font-semibold px-2 py-1 rounded border border-slate-150 flex items-center gap-1">
                                  <MapPin className="w-3 h-3 text-indigo-500" /> {c}
                                </span>
                              ))}
                            </div>
                          </div>

                          <div>
                            <span className="text-[11px] text-slate-400 block uppercase font-mono">Target Industries</span>
                            <div className="flex flex-wrap gap-1 mt-1">
                              {currentPath.globalDemand.industries.map((ind, i) => (
                                <span key={i} className="text-xs bg-indigo-50/50 text-indigo-800 font-medium px-2 py-0.5 rounded">
                                  {ind}
                                </span>
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="mt-5 pt-3 border-t border-slate-100/60 flex items-center justify-between text-xs font-semibold">
                        <span className="text-slate-500">Projected Market Growth:</span>
                        <span className="font-mono text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">{currentPath.globalDemand.growthRate}</span>
                      </div>
                    </div>

                    {/* Salary Benchmark Card */}
                    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 flex flex-col justify-between">
                      <div>
                        <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
                          <h3 className="font-bold text-sm text-slate-900 uppercase tracking-wider flex items-center gap-1.5 font-display">
                            <DollarSign className="w-4 h-4 text-indigo-600" /> Salary Benchmarking
                          </h3>
                          <span className="text-[10px] text-slate-400 font-mono">Annual Estimates</span>
                        </div>

                        <div className="grid grid-cols-2 gap-4 mt-2">
                          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200/50">
                            <span className="text-[10px] text-slate-400 block font-mono uppercase">India Entry</span>
                            <span className="text-base font-black text-slate-900 block mt-1 font-display">
                              {currentPath.salaryRanges.india}
                            </span>
                            <span className="text-[9px] text-slate-500 block mt-0.5 leading-tight">Average starting CTC</span>
                          </div>

                          <div className="bg-indigo-50/40 p-3.5 rounded-xl border border-indigo-100/50">
                            <span className="text-[10px] text-indigo-500 block font-mono uppercase">Global Entry</span>
                            <span className="text-base font-black text-slate-900 block mt-1 font-display">
                              {currentPath.salaryRanges.global}
                            </span>
                            <span className="text-[9px] text-slate-500 block mt-0.5 leading-tight">US/EU equivalents</span>
                          </div>
                        </div>
                      </div>

                      <p className="text-[10px] text-slate-500 leading-relaxed mt-4">
                        *Salaries scale exponentially based on certified skill portfolios. Master the gap skills below to target upper bands.
                      </p>
                    </div>

                  </div>

                  {/* Indian Job Market Scope & Ecosystem */}
                  {(() => {
                    const indianScope = indianMarketScopeData[currentPath.id];
                    if (!indianScope) return null;
                    return (
                      <div className="bg-gradient-to-br from-indigo-950 via-slate-900 to-slate-950 text-white rounded-3xl p-6 sm:p-8 shadow-lg relative overflow-hidden border border-indigo-500/10">
                        {/* Elegant Tricolor Accent */}
                        <div className="absolute top-0 left-0 right-0 h-[3px] flex">
                          <div className="flex-1 bg-amber-500" />
                          <div className="flex-1 bg-white" />
                          <div className="flex-1 bg-emerald-500" />
                        </div>

                        <div className="relative z-10">
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-4 mb-6">
                            <div>
                              <span className="text-[10px] uppercase font-bold tracking-widest text-amber-400 font-mono">Domestic Scope</span>
                              <h3 className="text-lg sm:text-xl font-black font-display tracking-tight text-white flex items-center gap-2 mt-1">
                                <span>🇮🇳</span> Indian Job Market & Hiring Ecosystem
                              </h3>
                            </div>
                            
                            <div className="flex items-center gap-2.5">
                              <span className="text-[11px] text-slate-400 font-mono uppercase tracking-wider">Domestic Demand:</span>
                              <span className={`px-2.5 py-1 rounded-md text-[10px] font-black uppercase tracking-wider ${
                                indianScope.outlook === 'Explosive' ? 'bg-rose-500 text-white animate-pulse' :
                                indianScope.outlook === 'Very High' ? 'bg-amber-500 text-slate-950' :
                                indianScope.outlook === 'High' ? 'bg-emerald-500 text-slate-950' :
                                'bg-indigo-500 text-white'
                              }`}>
                                {indianScope.outlook}
                              </span>
                            </div>
                          </div>

                          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                            {/* Left Column: Narrative Trend & Drivers */}
                            <div className="lg:col-span-7 space-y-5">
                              <div>
                                <h4 className="text-[11px] font-bold uppercase tracking-wider text-indigo-300 font-mono mb-2">Market Trends & Trajectory</h4>
                                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-normal">
                                  {indianScope.marketTrends}
                                </p>
                              </div>

                              <div>
                                <h4 className="text-[11px] font-bold uppercase tracking-wider text-indigo-300 font-mono mb-2.5">Key Domestic Growth Drivers</h4>
                                <div className="grid grid-cols-1 sm:grid-cols-1 gap-2">
                                  {indianScope.demandDrivers.map((driver, idx) => (
                                    <div key={idx} className="flex gap-2.5 p-3 rounded-xl bg-white/[0.03] hover:bg-white/[0.05] border border-white/5 transition-all">
                                      <div className="w-5 h-5 rounded-full bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center shrink-0 mt-0.5">
                                        <CheckCircle className="w-3 h-3 text-emerald-400" />
                                      </div>
                                      <span className="text-xs text-slate-300 leading-normal">{driver}</span>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            </div>

                            {/* Right Column: Cities & Employers */}
                            <div className="lg:col-span-5 space-y-4">
                              <div className="p-4 sm:p-5 rounded-2xl bg-white/[0.03] border border-white/5 space-y-4">
                                <div>
                                  <h4 className="text-[11px] font-bold uppercase tracking-wider text-indigo-300 font-mono mb-2 flex items-center gap-1.5">
                                    <MapPin className="w-3.5 h-3.5 text-amber-400" /> Active Hiring Hubs
                                  </h4>
                                  <div className="flex flex-wrap gap-1.5 mt-2">
                                    {indianScope.hiringHubs.map((city, idx) => (
                                      <span key={idx} className="text-[11px] bg-white/[0.08] text-white font-medium px-2 py-0.5 rounded border border-white/5">
                                        {city}
                                      </span>
                                    ))}
                                  </div>
                                </div>

                                <div className="pt-4 border-t border-white/5">
                                  <h4 className="text-[11px] font-bold uppercase tracking-wider text-indigo-300 font-mono mb-2 flex items-center gap-1.5">
                                    <Briefcase className="w-3.5 h-3.5 text-emerald-400" /> Prominent Domestic Employers
                                  </h4>
                                  <div className="flex flex-wrap gap-1.5 mt-2">
                                    {indianScope.prominentEmployers.map((emp, idx) => (
                                      <span key={idx} className="text-[11px] bg-indigo-500/10 text-indigo-200 font-medium px-2 py-0.5 rounded border border-indigo-500/10">
                                        {emp}
                                      </span>
                                    ))}
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })()}

                  {/* Target Roles breakdown */}
                  <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
                    <h3 className="font-bold text-sm text-slate-900 uppercase tracking-wider mb-4 border-b border-slate-100 pb-2 flex items-center gap-2 font-display">
                      <Briefcase className="w-4 h-4 text-indigo-600" /> Target Global Job Titles
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {currentPath.targetRoles.map((role, idx) => (
                        <div key={idx} className="p-4 rounded-xl border border-slate-100 bg-slate-50/50 flex flex-col justify-between">
                          <div>
                            <h4 className="font-extrabold text-sm text-slate-900 font-display flex items-center gap-1.5">
                              <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 shrink-0" />
                              {role.title}
                            </h4>
                            <p className="text-xs text-slate-500 mt-2 leading-relaxed">
                              {role.description}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Personalized Skill Gap Evaluator & Gauge */}
                  <div className="bg-slate-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />
                    <div className="absolute bottom-0 left-0 w-80 h-80 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />

                    <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                      
                      {/* Left: Gauge */}
                      <div className="lg:col-span-5 text-center flex flex-col items-center">
                        <span className="text-xs text-indigo-300 font-mono tracking-wider uppercase">Interactive Gauge</span>
                        <h4 className="text-xl font-black mt-1 font-display">Your Global Readiness</h4>
                        
                        {/* Custom Animated SVG Radial Progress */}
                        <div className="relative w-40 h-40 mt-5 flex items-center justify-center">
                          <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                            {/* Track circle */}
                            <circle 
                              cx="50" cy="50" r="42" 
                              fill="transparent" 
                              stroke="#1e293b" 
                              strokeWidth="7" 
                            />
                            {/* Value circle */}
                            <motion.circle 
                              cx="50" cy="50" r="42" 
                              fill="transparent" 
                              stroke="url(#indigoGradient)" 
                              strokeWidth="8" 
                              strokeDasharray="264"
                              strokeDashoffset={264 - (264 * readinessMetrics.percent) / 100}
                              strokeLinecap="round"
                              transition={{ duration: 0.5, ease: "easeOut" }}
                            />
                            <defs>
                              <linearGradient id="indigoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                                <stop offset="0%" stopColor="#6366f1" />
                                <stop offset="100%" stopColor="#a855f7" />
                              </linearGradient>
                            </defs>
                          </svg>
                          
                          {/* Inner Percentage Label */}
                          <div className="absolute flex flex-col items-center justify-center">
                            <span className="text-3xl font-black tracking-tight font-display text-white">
                              {readinessMetrics.percent}%
                            </span>
                            <span className="text-[10px] text-slate-400 font-mono mt-0.5 uppercase">
                              {readinessMetrics.acquired}/{readinessMetrics.total} Mapped
                            </span>
                          </div>
                        </div>

                        {/* Status Message based on percentage */}
                        <p className="text-xs text-slate-300 mt-4 px-4 leading-relaxed">
                          {readinessMetrics.percent === 100 ? (
                            <span className="text-emerald-400 font-semibold flex items-center justify-center gap-1">
                              <CheckCircle className="w-3.5 h-3.5" /> Ready to Apply Globally!
                            </span>
                          ) : readinessMetrics.percent >= 60 ? (
                            'Solid baseline! Acquire the remaining credentials to unlock senior profiles.'
                          ) : readinessMetrics.percent >= 30 ? (
                            'Moderate readiness. Focus on the core Practical & Certifications tools below.'
                          ) : (
                            'Action required. Start marking off your core qualifications to animate progress.'
                          )}
                        </p>
                      </div>

                      {/* Right: Skill Matrix Checklist */}
                      <div className="lg:col-span-7 space-y-4">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-extrabold text-sm uppercase tracking-wider text-slate-300 font-display">
                            Verify Your Skill Matrix
                          </h4>
                          <span className="text-xs text-slate-400">Click to check your acquired skills</span>
                        </div>

                        <div className="space-y-2.5 max-h-[320px] overflow-y-auto pr-2 custom-scrollbar">
                          {currentPath.skillsMatrix.map((skill, sIdx) => {
                            const isChecked = !!acquiredSkills[`${currentPath.id}_${skill.name}`];
                            return (
                              <button
                                key={sIdx}
                                onClick={() => toggleSkill(currentPath.id, skill.name)}
                                className={`w-full text-left p-3 rounded-xl border text-xs transition-all flex items-start gap-3 ${
                                  isChecked 
                                    ? 'bg-slate-900 border-indigo-500/50 text-white' 
                                    : 'bg-slate-900/40 border-slate-800 text-slate-300 hover:bg-slate-900/70 hover:border-slate-700'
                                }`}
                              >
                                <div className="shrink-0 mt-0.5">
                                  {isChecked ? (
                                    <div className="p-0.5 bg-indigo-500 rounded-full text-white">
                                      <CheckCircle2 className="w-3.5 h-3.5" />
                                    </div>
                                  ) : (
                                    <div className="w-4.5 h-4.5 rounded-full border-2 border-slate-600 hover:border-slate-400" />
                                  )}
                                </div>
                                <div className="flex-1 min-w-0">
                                  <div className="flex items-center justify-between gap-2 flex-wrap">
                                    <span className="font-bold tracking-wide block truncate">{skill.name}</span>
                                    <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold tracking-wider uppercase ${
                                      skill.category === 'Technical' ? 'bg-indigo-950 text-indigo-400 border border-indigo-800/40' :
                                      skill.category === 'Practical' ? 'bg-amber-950 text-amber-400 border border-amber-800/40' :
                                      skill.category === 'Certification' ? 'bg-red-950 text-red-400 border border-red-800/40' :
                                      'bg-emerald-950 text-emerald-400 border border-emerald-800/40'
                                    }`}>
                                      {skill.category}
                                    </span>
                                  </div>
                                  <p className="text-slate-400 text-[11px] mt-1 leading-normal">
                                    {skill.description}
                                  </p>
                                  <p className="text-indigo-300 text-[10px] mt-1.5 font-medium flex items-center gap-1 font-mono">
                                    <BookOpen className="w-3.5 h-3.5" /> Resource: {skill.recommendedResource}
                                  </p>
                                </div>
                              </button>
                            );
                          })}
                        </div>
                      </div>

                    </div>
                  </div>

                  {/* Standard Static Roadmap and Action Steps */}
                  <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
                    <h3 className="font-bold text-sm text-slate-900 uppercase tracking-wider mb-4 border-b border-slate-100 pb-2 flex items-center gap-2 font-display">
                      <BookOpen className="w-4 h-4 text-indigo-600" /> Fasttrack Launch Action Roadmap
                    </h3>
                    <div className="space-y-4">
                      {currentPath.careerRoadmapSteps.map((step, idx) => (
                        <div key={idx} className="flex gap-4 items-start">
                          <div className="w-6 h-6 rounded-full bg-indigo-50 border border-indigo-200 flex items-center justify-center text-xs font-bold text-indigo-600 shrink-0 font-mono">
                            {idx + 1}
                          </div>
                          <div className="pt-0.5">
                            <p className="text-sm font-semibold text-slate-800">{step}</p>
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="mt-6 p-4 bg-indigo-50/50 rounded-xl border border-indigo-100">
                      <h4 className="text-xs font-bold text-indigo-900 uppercase tracking-wide flex items-center gap-1">
                        💡 Pro-Tips for Global Recruitment:
                      </h4>
                      <ul className="mt-2 space-y-2 text-xs text-slate-600">
                        {currentPath.fasttrackTips.map((tip, idx) => (
                          <li key={idx} className="flex gap-2 items-start leading-relaxed">
                            <span className="text-indigo-500 mt-1">•</span>
                            <span>{tip}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* AI Copilot Advisor Input Console */}
                  <div id="ai-advisor-panel" className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-2xl border border-indigo-200/50 p-6 shadow-sm">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="p-1.5 bg-indigo-600 rounded-lg text-white">
                        <Sparkles className="w-4 h-4" />
                      </div>
                      <h3 className="font-bold text-base text-indigo-950 font-display">Get Your Personalized AI Action Plan</h3>
                    </div>
                    <p className="text-xs text-slate-600 leading-relaxed mb-4">
                      Our Gemini AI consultant will evaluate your current skill checks, analyze your specific gaps in detail, and write a customized corporate onboarding bridge strategy.
                    </p>

                    <div className="space-y-4">
                      <div>
                        <label className="text-xs font-bold text-indigo-900 block mb-1">Your background details (e.g. academic scores, internships, or coding projects)</label>
                        <textarea
                          value={experienceNotes}
                          onChange={(e) => setExperienceNotes(e.target.value)}
                          placeholder="Example: I got 82% in my B.Tech CSE, have built a basic e-commerce store with React, and know some basic DevOps. No prior work experience."
                          className="w-full bg-white border border-slate-200 rounded-xl p-3 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-indigo-500 transition-all focus:ring-1 focus:ring-indigo-500 min-h-[75px]"
                        />
                      </div>

                      <div>
                        <label className="text-xs font-bold text-indigo-900 block mb-1">Additional Career Targets / Preferred Destination</label>
                        <textarea
                          value={additionalGoals}
                          onChange={(e) => setAdditionalGoals(e.target.value)}
                          placeholder="Example: I want to relocate to Germany or work remotely for an Singaporean FinTech startup in 2 years."
                          className="w-full bg-white border border-slate-200 rounded-xl p-3 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-indigo-500 transition-all focus:ring-1 focus:ring-indigo-500 min-h-[60px]"
                        />
                      </div>

                      <div className="flex items-center justify-between flex-wrap gap-4 pt-2">
                        <div className="text-xs text-indigo-950 font-medium font-mono">
                          Mapped: {readinessMetrics.acquired} of {readinessMetrics.total} skills checked
                        </div>
                        <button
                          onClick={generateAIReport}
                          className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold tracking-wide shadow-md shadow-indigo-200 flex items-center gap-2 cursor-pointer transition-all"
                        >
                          <Sparkles className="w-4 h-4" /> Generate AI Report
                        </button>
                      </div>
                    </div>
                  </div>

                </motion.div>
              </AnimatePresence>
            )}

          </div>

        </div>

        {/* Global Hotspots Showcase Grid */}
        <section id="hotspots-section" className="mt-16">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-extrabold text-slate-900 font-display">Global Career Opportunities & Visas</h2>
            <p className="text-xs text-slate-500 mt-1 max-w-lg mx-auto">
              Hotspots across the globe actively recruiting skilled candidates matching standard Indian technical and professional pathways.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            {trendingGlobalJobs.map((job, i) => (
              <div key={i} className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm hover:shadow-md transition-all flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-[9px] bg-slate-100 text-slate-600 font-mono font-bold px-2 py-0.5 rounded">
                      {job.location}
                    </span>
                    <Globe2 className="w-4 h-4 text-slate-400" />
                  </div>
                  <h4 className="font-extrabold text-xs text-slate-900 leading-tight font-display">{job.title}</h4>
                  <p className="text-[10px] text-slate-500 mt-2">
                    Fits: <span className="text-indigo-600 font-medium">{job.match}</span>
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100/60 flex items-center justify-between text-[10px] font-semibold">
                  <span className="text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded font-mono">{job.pay}</span>
                  <span className="text-slate-400 uppercase font-mono tracking-wider">{job.demand}</span>
                </div>
              </div>
            ))}
          </div>
        </section>

      </main>

      {/* Interactive Floating AI Advisor Modal */}
      <AnimatePresence>
        {showAIModal && (
          <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-3xl max-w-3xl w-full shadow-2xl border border-slate-200/60 overflow-hidden flex flex-col max-h-[85vh]"
            >
              {/* Modal Header */}
              <div className="p-5 border-b border-slate-100 bg-indigo-50/20 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-indigo-600" />
                  <div>
                    <h3 className="font-black text-slate-900 text-sm font-display leading-tight">Your Custom Career Launch Plan</h3>
                    <p className="text-[10px] text-slate-500 mt-0.5 font-mono">Formulated by Gemini AI Expert</p>
                  </div>
                </div>
                <button 
                  onClick={() => setShowAIModal(false)}
                  className="text-xs text-slate-400 hover:text-slate-600 font-bold border border-slate-200/80 px-2.5 py-1 rounded-lg"
                >
                  Close
                </button>
              </div>

              {/* Modal Content */}
              <div className="p-6 overflow-y-auto flex-1 custom-scrollbar">
                {aiLoading ? (
                  <div className="py-20 text-center flex flex-col items-center justify-center">
                    {/* Visual Wave Loader */}
                    <div className="flex items-end gap-1.5 h-10 mb-4 justify-center">
                      <div className="w-1.5 bg-indigo-600 rounded wave-bar h-6" />
                      <div className="w-1.5 bg-indigo-500 rounded wave-bar h-10" />
                      <div className="w-1.5 bg-purple-600 rounded wave-bar h-8" />
                      <div className="w-1.5 bg-purple-500 rounded wave-bar h-12" />
                      <div className="w-1.5 bg-pink-500 rounded wave-bar h-5" />
                    </div>
                    <p className="text-sm font-bold text-slate-800 font-display">Scanning Education Frameworks...</p>
                    <p className="text-xs text-slate-500 mt-1 max-w-sm">Generating target milestone mappings, custom sample projects, and resources based on your skill gaps.</p>
                  </div>
                ) : aiError ? (
                  <div className="p-4 bg-red-50 rounded-2xl border border-red-100 flex items-start gap-3 text-xs text-red-700">
                    <AlertCircle className="w-5 h-5 shrink-0 text-red-500" />
                    <div>
                      <span className="font-bold block">Advisory Connection Outage</span>
                      <p className="mt-1 leading-relaxed">{aiError}</p>
                      <div className="mt-3 bg-white p-2.5 rounded-lg border border-red-100/60 text-slate-600 text-[10px] leading-relaxed">
                        <span className="font-semibold block text-slate-800">To enable full-stack Gemini capabilities:</span>
                        Please check if the <span className="font-semibold text-indigo-600">GEMINI_API_KEY</span> secret is properly set in the AI Studio **Settings &gt; Secrets** tab in your browser workspace.
                      </div>
                    </div>
                  </div>
                ) : aiReport ? (
                  <div className="prose prose-slate prose-xs max-w-none prose-headings:font-display prose-headings:font-bold prose-headings:tracking-tight prose-headings:text-slate-950 prose-p:text-slate-600 prose-p:leading-relaxed prose-li:text-slate-600">
                    <ReactMarkdown>{aiReport}</ReactMarkdown>
                  </div>
                ) : (
                  <div className="text-center text-slate-400 text-xs py-10">
                    No plan generated. Press "Generate AI Report" to create.
                  </div>
                )}
              </div>

              {/* Modal Footer */}
              <div className="p-4 bg-slate-50 border-t border-slate-100 flex justify-end gap-3">
                <button
                  onClick={() => setShowAIModal(false)}
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold"
                >
                  Dismiss Report
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* humble design-focused footer */}
      <footer id="footer" className="mt-20 border-t border-slate-200 bg-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-xs text-slate-500">
          <p className="font-bold text-slate-700">Fasttrack Career Launchers</p>
          <p className="mt-1.5 leading-relaxed">
            Helping Indian degree holders evaluate specialized gaps, match global industries, and access customized micro-roadmaps.
          </p>
          <div className="mt-4 flex items-center justify-center gap-6 font-mono text-[10px] text-slate-400">
            <span>UGC & AICTE Curriculum Maps</span>
            <span>•</span>
            <span>Dual Benchmark (INR vs Global)</span>
            <span>•</span>
            <span>Personalized Readiness Gauge</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
