export interface SkillItem {
  name: string;
  category: 'Technical' | 'Practical' | 'Certification' | 'Soft Skills';
  description: string;
  recommendedResource: string;
}

export interface CareerPath {
  id: string;
  title: string;
  description: string;
  globalDemand: {
    countries: string[];
    industries: string[];
    growthRate: string; // e.g., '15% CAGR'
    outlook: 'High' | 'Very High' | 'Stable' | 'Explosive';
  };
  salaryRanges: {
    india: string; // e.g., '₹6L - ₹15L'
    global: string; // e.g., '$70k - $120k'
  };
  targetRoles: {
    title: string;
    description: string;
  }[];
  skillsMatrix: SkillItem[];
  careerRoadmapSteps: string[];
  fasttrackTips: string[];
}

export interface QualificationData {
  id: string;
  name: string;
  category: 'Commerce' | 'Science' | 'Engineering' | 'Diploma';
  fullForm: string;
  description: string;
  commonSpecializations: string[];
  careerPaths: CareerPath[];
}

export const qualificationsData: QualificationData[] = [
  {
    id: 'bcom',
    name: 'B.Com',
    category: 'Commerce',
    fullForm: 'Bachelor of Commerce',
    description: 'A comprehensive 3-year undergraduate degree focusing on accounting, finance, taxation, economics, and business laws under the Indian university system.',
    commonSpecializations: ['General', 'Accounting & Finance (A&F)', 'Honours', 'Computer Applications', 'Taxation'],
    careerPaths: [
      {
        id: 'corp-accounting',
        title: 'Corporate Accounting & Financial Analysis',
        description: 'Manage accounts, prepare financial reports, audit ledgers, and analyze business performance for global enterprises.',
        globalDemand: {
          countries: ['India', 'USA', 'UK', 'Singapore', 'UAE'],
          industries: ['IT Services', 'Manufacturing', 'Retail', 'Consulting', 'FMCG'],
          growthRate: '8% CAGR',
          outlook: 'Stable'
        },
        salaryRanges: {
          india: '₹3.5L - ₹8L p.a.',
          global: '$55,000 - $85,000 p.a.'
        },
        targetRoles: [
          { title: 'Financial Analyst', description: 'Analyze business performance, model forecasts, and support corporate strategy.' },
          { title: 'Corporate Accountant', description: 'Manage general ledger, prepare balance sheets, and ensure compliance.' },
          { title: 'Tax Consultant', description: 'Provide guidance on direct/indirect taxes and global transfer pricing.' }
        ],
        skillsMatrix: [
          { name: 'Financial Accounting & GAAP', category: 'Technical', description: 'Understanding double-entry, ledger balancing, and Indian AS / IFRS standards.', recommendedResource: 'ICA / IFRS Foundations Course' },
          { name: 'Advanced MS Excel', category: 'Practical', description: 'VLOOKUPs, Pivot Tables, financial modeling, and macro basics.', recommendedResource: 'Excel for Finance Bootcamp' },
          { name: 'Tally Prime / SAP FICO', category: 'Practical', description: 'Industry-standard ERP software for managing enterprise records in India and globally.', recommendedResource: 'SAP FICO Certification' },
          { name: 'Certified Public Accountant (CPA)', category: 'Certification', description: 'Global accounting credentials accepted in US and multinational firms.', recommendedResource: 'AICPA Prep Course' },
          { name: 'Chartered Accountancy (CA - Inter)', category: 'Certification', description: 'Highly valued credential in India proving advanced audit and tax knowledge.', recommendedResource: 'ICAI Study Modules' },
          { name: 'Financial Modeling', category: 'Practical', description: 'Building dynamic forecasts, DCF analysis, and valuation sheets.', recommendedResource: 'CFI Financial Analyst Course' },
          { name: 'Business Communication', category: 'Soft Skills', description: 'Explaining numerical data clearly to non-finance stakeholders.', recommendedResource: 'Corporate Writing & Presentation Seminar' }
        ],
        careerRoadmapSteps: [
          'Master Advanced Excel & Financial Modeling during your graduation.',
          'Obtain Practical ERP certification (Tally Prime or SAP FICO module).',
          'Gain internship experience in a mid-tier accounting firm or MNC Shared Services.',
          'Enroll in professional certifications (CPA, ACCA, or CA) to gain global weight.',
          'Apply for Financial Analyst roles in global accounting firms or Big 4 consulting.'
        ],
        fasttrackTips: [
          'MNCs love candidates with ACCA (UK) or CPA (US) credentials as they understand global reporting standards.',
          'Participate in stock market simulation contests and build a portfolio of dummy equity research to stand out.'
        ]
      },
      {
        id: 'investment-banking',
        title: 'Investment Banking & Wealth Management',
        description: 'Support mergers & acquisitions, raising capital, portfolio management, and financial advisory for high-net-worth clients.',
        globalDemand: {
          countries: ['USA', 'UK', 'Singapore', 'Hong Kong', 'India (Mumbai/Bengaluru)'],
          industries: ['Investment Banking', 'Private Equity', 'Wealth Advisory', 'Brokerages'],
          growthRate: '12% CAGR',
          outlook: 'High'
        },
        salaryRanges: {
          india: '₹6L - ₹18L p.a.',
          global: '$85,000 - $150,000 p.a.'
        },
        targetRoles: [
          { title: 'Investment Banking Analyst', description: 'Build pitchbooks, perform valuation models, and assist in M&A deals.' },
          { title: 'Wealth Manager / Portfolio Advisor', description: 'Structure investment portfolios, mutual fund baskets, and debt instruments for clients.' },
          { title: 'Risk Management Associate', description: 'Analyze market, credit, and operational risks of financial portfolios.' }
        ],
        skillsMatrix: [
          { name: 'Valuation & DCF Modeling', category: 'Technical', description: 'Estimating company worth using discounted cash flow and comparable comps analysis.', recommendedResource: 'Corporate Finance Institute (CFI)' },
          { name: 'Chartered Financial Analyst (CFA L1)', category: 'Certification', description: 'Gold standard global qualification for investment analysis.', recommendedResource: 'CFA Institute Prep' },
          { name: 'NISM Certifications', category: 'Certification', description: 'Mandatory exams in India (Series VIII / V-A) for equity derivatives and mutual fund operations.', recommendedResource: 'NISM Portal Exams' },
          { name: 'Python for Finance', category: 'Practical', description: 'Using pandas and numpy to automate data analysis and backtest strategies.', recommendedResource: 'DataCamp Python for Finance' },
          { name: 'Financial Markets Knowledge', category: 'Technical', description: 'Deep understanding of monetary policies, bond markets, derivatives, and macroeconomic indicators.', recommendedResource: 'Wall Street Journal / Economic Times' },
          { name: 'Pitch Deck Creation', category: 'Practical', description: 'Creating persuasive visual presentations explaining complex financial propositions.', recommendedResource: 'PowerPoint Design Masterclass' },
          { name: 'Client Advising & Negotiation', category: 'Soft Skills', description: 'Building trust, negotiating terms, and pitching financial options.', recommendedResource: 'Negotiation Workshops' }
        ],
        careerRoadmapSteps: [
          'Acquire CFA Level 1 during or immediately after your B.Com.',
          'Earn Indian regulatory clearances like NISM certifications to demonstrate immediate local employability.',
          'Develop strong financial modeling and Python-based quantitative skills.',
          'Target specialized wealth management advisories and global bank operations (e.g., Goldman Sachs, JP Morgan back-offices in India).',
          'Progress to M&A advisory or direct client portfolio management.'
        ],
        fasttrackTips: [
          'MNC back-offices in India (GBCs) are massive pipelines for global investment banking teams. Work hard, request transfers, and leverage corporate credentials.',
          'Write equity research reports on mid-cap Indian companies and publish them on LinkedIn/Medium to catch recruiter eyeballs.'
        ]
      }
    ]
  },
  {
    id: 'mcom',
    name: 'M.Com',
    category: 'Commerce',
    fullForm: 'Master of Commerce',
    description: 'A 2-year postgraduate degree designed for advanced specialized education in commerce, statistics, financial management, and research methodologies.',
    commonSpecializations: ['Finance', 'Accounting', 'Taxation', 'Banking & Insurance', 'Business Management'],
    careerPaths: [
      {
        id: 'academic-research',
        title: 'Academic Research & Professional Education',
        description: 'Become an assistant professor, educational consultant, curriculum architect, or academic researcher in leading universities.',
        globalDemand: {
          countries: ['India', 'UK', 'Australia', 'Canada', 'Singapore'],
          industries: ['Universities', 'EdTech Companies', 'Government Research Wings', 'Corporate Training'],
          growthRate: '10% CAGR',
          outlook: 'Stable'
        },
        salaryRanges: {
          india: '₹5L - ₹12L p.a.',
          global: '$60,000 - $95,000 p.a.'
        },
        targetRoles: [
          { title: 'Assistant Professor (Commerce)', description: 'Teach advanced undergraduate and postgraduate accounting and finance courses.' },
          { title: 'Curriculum Developer', description: 'Design commerce courses, assessments, and pedagogical pathways for EdTech platforms.' },
          { title: 'Academic Researcher', description: 'Conduct econometric research, publish in ABDC/Scopus journals.' }
        ],
        skillsMatrix: [
          { name: 'UGC NET / SET Exam', category: 'Certification', description: 'Mandatory qualification in India for assistant professorships in universities.', recommendedResource: 'NTA UGC NET Exam Guides' },
          { name: 'Statistical Tools (SPSS / R)', category: 'Practical', description: 'Analyzing quantitative survey data and running multivariate regressions.', recommendedResource: 'R Programming for Social Sciences' },
          { name: 'Research Methodology', category: 'Technical', description: 'Structuring hypotheses, designing questionnaires, and understanding qualitative research.', recommendedResource: 'SAGE Research Methods Handbooks' },
          { name: 'Pedagogical Design', category: 'Technical', description: 'Structuring classroom engagements, outcome-based learning, and interactive case studies.', recommendedResource: 'Harvard Case Method Teaching Seminar' },
          { name: 'Presentation & Public Speaking', category: 'Soft Skills', description: 'Commanding a classroom of 60+ students and explaining complex theories simply.', recommendedResource: 'Toastmasters International Club' },
          { name: 'Educational Tech Integration', category: 'Practical', description: 'Managing Canvas, Moodle, and digital evaluation suites.', recommendedResource: 'Google Certified Educator' }
        ],
        careerRoadmapSteps: [
          'Clear the UGC NET-JRF (Junior Research Fellowship) during the final year of M.Com.',
          'Apply for Ph.D. programs in top central/state universities or premier business schools (IIMs).',
          'Publish research papers in high-quality Scopus/ABDC indexed journals.',
          'Start as an Assistant Professor on ad-hoc or tenure-track positions.',
          'Acquire global fellowships (e.g., Fulbright, Commonwealth) to expand lecturing horizons.'
        ],
        fasttrackTips: [
          'Clearing UGC NET-JRF grants you a monthly stipend of ₹37,000+ to pursue your doctoral studies, making it an excellent bridge step.',
          'Gain familiarity with ESG (Environmental, Social, and Governance) reporting as this is the fastest-growing academic research domain in business schools worldwide.'
        ]
      },
      {
        id: 'treasury-management',
        title: 'Corporate Treasury & Internal Audit',
        description: 'Oversee corporate cash flows, foreign exchange hedges, corporate credit compliance, and risk audits for multinational corporations.',
        globalDemand: {
          countries: ['UAE', 'Ireland', 'Luxembourg', 'India', 'USA'],
          industries: ['Banking', 'Large Infrastructure conglomerates', 'Global Tech MNCs', 'Aviation'],
          growthRate: '9% CAGR',
          outlook: 'High'
        },
        salaryRanges: {
          india: '₹5.5L - ₹14L p.a.',
          global: '$75,000 - $115,000 p.a.'
        },
        targetRoles: [
          { title: 'Treasury Analyst', description: 'Monitor liquidity, manage foreign exchange risks, and execute hedging strategies.' },
          { title: 'Internal Auditor', description: 'Review corporate operational workflows, compliance policies, and assess financial controls.' },
          { title: 'Credit Risk Analyst', description: 'Evaluate financial health of corporate partners and assign internal credit limits.' }
        ],
        skillsMatrix: [
          { name: 'Certified Internal Auditor (CIA)', category: 'Certification', description: 'Globally recognized credential for corporate auditing from IIA (USA).', recommendedResource: 'Institute of Internal Auditors Portal' },
          { name: 'Forex Markets & Derivatives', category: 'Technical', description: 'Understanding spot rates, forward contracts, swaps, and currency hedges.', recommendedResource: 'NISM Currency Derivatives Module' },
          { name: 'Corporate Liquidity Management', category: 'Technical', description: 'Optimizing cash buffers, managing working capital, and structuring commercial papers.', recommendedResource: 'Association for Financial Professionals (AFP)' },
          { name: 'Audit Automation Tools', category: 'Practical', description: 'Using computerized audit software like ACL or CaseWare.', recommendedResource: 'CaseWare Analytics training' },
          { name: 'Ethical Reasoning & Diligence', category: 'Soft Skills', description: 'Ensuring zero tolerance for financial malpractice and standing firm during disputes.', recommendedResource: 'Corporate Governance Ethics seminars' }
        ],
        careerRoadmapSteps: [
          'Acquire standard M.Com coursework with focus on financial management.',
          'Earn the CIA (Certified Internal Auditor) or CTP (Certified Treasury Professional) credential.',
          'Secure an auditing role inside the risk advisory wing of a tier-2 or Big 4 audit firm.',
          'Transition into client-side corporate treasury teams of major MNCs.',
          'Head global treasury operations, currency hedging portfolios, or corporate risk assurance.'
        ],
        fasttrackTips: [
          'Major companies with heavy imports/exports (like Reliance or Tata) have highly sophisticated treasury departments that actively seek M.Com majors with strong analytical minds.',
          'Understand SWIFT transaction codes and trade finance mechanisms (Letters of Credit, Bank Guarantees).'
        ]
      }
    ]
  },
  {
    id: 'bsc',
    name: 'B.Sc.',
    category: 'Science',
    fullForm: 'Bachelor of Science',
    description: 'A 3-year undergraduate degree offered in diverse fields like Computer Science, Information Technology, Physics, Chemistry, Mathematics, or Biotechnology.',
    commonSpecializations: ['Computer Science (CS)', 'Information Technology (IT)', 'Physics/Chemistry/Maths (PCM)', 'Biotechnology & Life Sciences', 'Data Science'],
    careerPaths: [
      {
        id: 'software-dev-bsc',
        title: 'Full-Stack Software Engineering',
        description: 'Build modern responsive web applications, robust backends, and maintain highly scalable software services.',
        globalDemand: {
          countries: ['India', 'USA', 'Germany', 'Japan', 'Ireland'],
          industries: ['Software Products', 'FinTech', 'E-commerce', 'HealthTech', 'Consulting'],
          growthRate: '18% CAGR',
          outlook: 'Explosive'
        },
        salaryRanges: {
          india: '₹4L - ₹12L p.a.',
          global: '$65,000 - $110,000 p.a.'
        },
        targetRoles: [
          { title: 'Frontend Developer', description: 'Construct visual interfaces and optimize rendering performance using React, Next, or Vue.' },
          { title: 'Backend Developer', description: 'Maintain REST APIs, server architecture, and databases using Node.js, Python, or Go.' },
          { title: 'QA Automation Engineer', description: 'Write automated end-to-end integration test suites with Playwright, Cypress, or Selenium.' }
        ],
        skillsMatrix: [
          { name: 'JavaScript / TypeScript', category: 'Technical', description: 'Deep comprehension of closures, event loops, async patterns, and strict typing.', recommendedResource: 'MDN Web Docs / TypeScript Deep Dive' },
          { name: 'React.js / Next.js', category: 'Technical', description: 'State management, hydration, component cycles, and modern routing systems.', recommendedResource: 'React Official Documentation' },
          { name: 'Node.js & Express.js', category: 'Technical', description: 'Building server runtimes, middleware pipelines, and API integrations.', recommendedResource: 'Backend Engineering Masterclass' },
          { name: 'SQL & Database Design', category: 'Technical', description: 'Writing efficient queries, indexing tables, and database normalization with PostgreSQL.', recommendedResource: 'SQL Zoo / Database Course' },
          { name: 'Git & GitHub Workflows', category: 'Practical', description: 'Branching, merging, pull requests, resolving conflicts, and CI/CD basics.', recommendedResource: 'GitHub Skills Platform' },
          { name: 'Data Structures & Algorithms', category: 'Technical', description: 'Arrays, hashes, binary trees, sorting, recursion, and time complexity analyses.', recommendedResource: 'LeetCode / NeetCode Roadmaps' },
          { name: 'Collaborative Problem Solving', category: 'Soft Skills', description: 'Breaking complex features down and communicating technical design choices clearly.', recommendedResource: 'Agile & Scrum Methodologies' }
        ],
        careerRoadmapSteps: [
          'Learn standard Web Development (HTML, CSS, JS, React) in your 1st and 2nd years.',
          'Build 3 major full-stack capstone projects and host them on GitHub.',
          'Prepare basic DSA (Data Structures & Algorithms) patterns for interview cycles.',
          'Apply for software engineering internships and participate in open-source hackathons.',
          'Secure Full-time software developer job roles.'
        ],
        fasttrackTips: [
          'Many tech companies do not require an engineering degree (B.Tech); a B.Sc. with a robust portfolio of public GitHub projects is equally competitive.',
          'Contribute to open-source software (OSS) or register for Google Summer of Code (GSoC) to instantly fast-track your resume.'
        ]
      },
      {
        id: 'biotech-lab',
        title: 'Clinical Research, Biotech & Quality Control',
        description: 'Conduct microbiological assays, analyze pharmaceutical quality metrics, and support drug safety trials.',
        globalDemand: {
          countries: ['Germany', 'USA', 'India (Hyderabad/Pune)', 'Switzerland', 'Singapore'],
          industries: ['Pharmaceuticals', 'Clinical Research Organizations (CRO)', 'AgriTech', 'Food Processing'],
          growthRate: '11% CAGR',
          outlook: 'High'
        },
        salaryRanges: {
          india: '₹3L - ₹7.5L p.a.',
          global: '$50,000 - $80,000 p.a.'
        },
        targetRoles: [
          { title: 'Clinical Research Coordinator', description: 'Supervise pharmaceutical trial phases, ensure safety and regulatory norms.' },
          { title: 'Quality Control Chemist / Microbiologist', description: 'Analyze chemical concentrations and assess biological purity in sterile cleanrooms.' },
          { title: 'Bio-informatics Analyst', description: 'Analyze genomic sequence data using statistical languages.' }
        ],
        skillsMatrix: [
          { name: 'Good Laboratory Practice (GLP)', category: 'Technical', description: 'Standard FDA protocols for conducting clinical and lab research safely.', recommendedResource: 'WHO GLP Handbook' },
          { name: 'High-Performance Liquid Chromatography (HPLC)', category: 'Practical', description: 'Operating critical analytical machines used to separate and measure mixture ingredients.', recommendedResource: 'Lab Machine Operations training' },
          { name: 'Bioinformatics (BLAST / Biopython)', category: 'Technical', description: 'Searching sequence databases and analyzing nucleotide sequences with code.', recommendedResource: 'NCBI Bioinformatics courses' },
          { name: 'Clinical Trial Management Systems (CTMS)', category: 'Practical', description: 'Using specialized software to track clinical test milestones and patient diaries.', recommendedResource: 'Oracle Clinical Training' },
          { name: 'Regulatory Compliance (FDA / CDSCO)', category: 'Technical', description: 'Complying with federal and international drug administration rules.', recommendedResource: 'CDSCO Regulatory Guidance papers' },
          { name: 'Analytical Report Writing', category: 'Soft Skills', description: 'Drafting precise laboratory audit notes with zero ambiguous assertions.', recommendedResource: 'Scientific Writing guides' }
        ],
        careerRoadmapSteps: [
          'Focus heavily on molecular biology, organic chemistry, or immunology modules.',
          'Secure a practical hands-on training module in HPLC / GC analysis at an authorized pharma lab.',
          'Pursue clinical research or data management certifications.',
          'Start in Quality Assurance/Control or as a Clinical trial assistant in major hubs.',
          'Aim for research associate roles in global MNCs or pursue an M.Sc./Ph.D. program.'
        ],
        fasttrackTips: [
          'Hyderabad is the vaccine capital of the world; major CROs there hire massive batches of B.Sc. Biotech graduates with lab analytical credentials.',
          'Adding a certificate in clinical data management (CDM) opens doors to remote, highly paid medical data analyst roles.'
        ]
      }
    ]
  },
  {
    id: 'msc',
    name: 'M.Sc.',
    category: 'Science',
    fullForm: 'Master of Science',
    description: 'A 2-year rigorous scientific postgraduate degree focusing on specialization, advanced mathematical modeling, and rigorous laboratory or computational research.',
    commonSpecializations: ['Data Science', 'Physics', 'Chemistry', 'Biotechnology', 'Mathematics & Computing'],
    careerPaths: [
      {
        id: 'data-science',
        title: 'Data Science & Machine Learning Engineering',
        description: 'Train machine learning models, design predictive analytics systems, and structure complex big-data pipelines.',
        globalDemand: {
          countries: ['USA', 'UK', 'Singapore', 'Canada', 'India'],
          industries: ['Tech Platforms', 'FinTech', 'E-commerce', 'Defense Research', 'Logistics'],
          growthRate: '22% CAGR',
          outlook: 'Explosive'
        },
        salaryRanges: {
          india: '₹7L - ₹20L p.a.',
          global: '$95,000 - $160,000 p.a.'
        },
        targetRoles: [
          { title: 'Data Scientist', description: 'Clean data, test statistical hypotheses, and train predictive machine learning models.' },
          { title: 'Machine Learning Engineer', description: 'Optimize model deployment, set up training grids, and implement NLP or Computer Vision systems.' },
          { title: 'Data Engineer', description: 'Construct robust data pipelines, orchestrate ETL jobs, and maintain Big Data lakes.' }
        ],
        skillsMatrix: [
          { name: 'Advanced Python (Pandas/Scikit)', category: 'Technical', description: 'Using scientific packages to perform matrix manipulation, cleaning, and modeling.', recommendedResource: 'Kaggle Learn / Data Science from Scratch' },
          { name: 'SQL & Data Warehousing', category: 'Technical', description: 'Writing heavy window functions and querying BigQuery or Snowflake platforms.', recommendedResource: 'Mode Analytics SQL' },
          { name: 'Probability & Applied Statistics', category: 'Technical', description: 'Bayesian inference, hypothesis testing, ANOVA, regressions, and stochastic models.', recommendedResource: 'Think Stats / MIT OpenCourseWare' },
          { name: 'Deep Learning (PyTorch / TensorFlow)', category: 'Technical', description: 'Neural network architectures (CNNs, Transformers, LSTMs) and model optimizations.', recommendedResource: 'DeepLearning.AI / Fast.ai' },
          { name: 'Big Data Tools (Spark / Hadoop)', category: 'Practical', description: 'Handling distributed data computing over thousands of nodes.', recommendedResource: 'Databricks Academy Spark Cert' },
          { name: 'MLOps (MLflow / Docker)', category: 'Practical', description: 'Containerizing machine learning models and tracking performance parameters.', recommendedResource: 'MLOps Zoomcamp' },
          { name: 'Data Storytelling & Visualization', category: 'Soft Skills', description: 'Presenting intricate mathematical correlations in easy, executive-level business charts.', recommendedResource: 'Storytelling with Data (Cole Knaflic)' }
        ],
        careerRoadmapSteps: [
          'Acquire strong baseline coding in Python/R and clean up math basics (Linear Algebra/Stats).',
          'Build and publish Kaggle notebooks and standard predictive projects on GitHub.',
          'Learn SQL and database querying at an advanced level.',
          'Acquire PyTorch / TensorFlow credentials alongside cloud (AWS/GCP) certificates.',
          'Apply for Junior Data Scientist or Machine Learning engineer roles.'
        ],
        fasttrackTips: [
          'If you have an M.Sc. in Maths or Physics, highlight your strong quantitative training; recruiters value statistical rigor far more than simple code syntax.',
          'Build a personal portfolio website containing interactive Streamlit or Gradio applications showcasing your live ML models.'
        ]
      },
      {
        id: 'r-d-chemist',
        title: 'Industrial R&D, Synthesis & Material Science',
        description: 'Formulate cosmetic products, research green polymers, and synthesize organic components for chemical and pharmaceutical companies.',
        globalDemand: {
          countries: ['Germany', 'Japan', 'USA', 'India (Gujarat/Mumbai)', 'South Korea'],
          industries: ['Specialty Chemicals', 'Paints & Coatings', 'Cosmetics', 'Agrochemicals'],
          growthRate: '7% CAGR',
          outlook: 'Stable'
        },
        salaryRanges: {
          india: '₹4.5L - ₹10L p.a.',
          global: '$65,000 - $105,000 p.a.'
        },
        targetRoles: [
          { title: 'R&D Formulation Scientist', description: 'Develop novel combinations of active ingredients for cosmetics, creams, or paints.' },
          { title: 'Synthetic Organic Chemist', description: 'Synthesize organic molecules for pharmaceutical research following cleanroom regulations.' },
          { title: 'Material Scientist', description: 'Research polymers, nanostructured coatings, and lighter, stronger composite materials.' }
        ],
        skillsMatrix: [
          { name: 'Organic Synthesis & Retrosynthesis', category: 'Technical', description: 'Designing synthetic paths to build targeted chemical structures from basic elements.', recommendedResource: 'Advanced Organic Chemistry (Carey & Sundberg)' },
          { name: 'Spectroscopy (NMR / FTIR / Mass)', category: 'Technical', description: 'Interpreting complex spectrum files to confirm chemical structure matches.', recommendedResource: 'Organic Spectroscopy tutorials' },
          { name: 'Formulation Technology', category: 'Technical', description: 'Understanding emulsion, suspension, and stability metrics in material mixtures.', recommendedResource: 'Society of Cosmetic Chemists certification' },
          { name: 'Lab Safety & OSHA compliance', category: 'Practical', description: 'Handling hazardous chemicals, toxic gases, and emergency cleanup protocols.', recommendedResource: 'OSHA Lab Standard guide' },
          { name: 'Scientific Documentation', category: 'Practical', description: 'Drafting precise laboratory journals and patent applications under IP guidelines.', recommendedResource: 'WIPO Patent Draft Course' }
        ],
        careerRoadmapSteps: [
          'Perform rigorous practical coursework with a focus on advanced organic/inorganic chemistry.',
          'Secure an internship at a CSIR (India) lab or industrial R&D department.',
          'Acquire specialization in spectroscopy analysis tools.',
          'Join specialty chemical majors (e.g., Asian Paints, Pidilite, Lubrizol) as an associate researcher.',
          'Advance to Lead Scientist or pursue industrial Ph.D. programs sponsored by companies.'
        ],
        fasttrackTips: [
          'The state of Gujarat in India holds a massive share of the chemical industry. Specialty chemicals companies there pay excellent packages to M.Sc. Chemistry graduates with analytical lab training.',
          'Specializing in ESG and green chemistry (reducing hazardous chemical waste) is a massive resume booster for global opportunities.'
        ]
      }
    ]
  },
  {
    id: 'be-btech',
    name: 'B.E. / B.Tech',
    category: 'Engineering',
    fullForm: 'Bachelor of Engineering / Technology',
    description: 'A 4-year premier technical professional undergraduate degree widely pursued in fields like Computer Science, Electronics, Mechanical, Civil, and Electrical Engineering.',
    commonSpecializations: ['Computer Science & Engineering (CSE)', 'Information Technology (IT)', 'Electronics & Communication (ECE)', 'Mechanical Engineering', 'Civil Engineering'],
    careerPaths: [
      {
        id: 'cloud-devops',
        title: 'Cloud Computing & DevOps Engineering',
        description: 'Design robust cloud architectures, automate code deployment, manage servers, and guarantee 99.99% system availability.',
        globalDemand: {
          countries: ['USA', 'Singapore', 'Germany', 'UK', 'India'],
          industries: ['SaaS Enterprises', 'FinTech Platforms', 'Cloud Service Providers', 'Consultancies'],
          growthRate: '20% CAGR',
          outlook: 'Explosive'
        },
        salaryRanges: {
          india: '₹6L - ₹22L p.a.',
          global: '$90,000 - $160,000 p.a.'
        },
        targetRoles: [
          { title: 'DevOps Engineer', description: 'Automate build pipelines, write infrastructure-as-code, and manage application servers.' },
          { title: 'Cloud Solutions Architect', description: 'Design highly available, scalable, secure, and cost-effective cloud structures on AWS/GCP.' },
          { title: 'Site Reliability Engineer (SRE)', description: 'Monitor system telemetry, optimize database loads, and coordinate disaster recovery pipelines.' }
        ],
        skillsMatrix: [
          { name: 'Linux System Administration', category: 'Technical', description: 'Understanding kernel basics, process management, shell scripting, and network filesystems.', recommendedResource: 'Linux Foundation SysAdmin Cert' },
          { name: 'Docker & Kubernetes', category: 'Technical', description: 'Containerizing applications, creating pods, scaling replicas, and microservice orchestration.', recommendedResource: 'CKA (Certified Kubernetes Administrator)' },
          { name: 'Infrastructure as Code (Terraform)', category: 'Practical', description: 'Writing declarative scripts to manage resources across clouds dynamically.', recommendedResource: 'HashiCorp Certified Terraform Associate' },
          { name: 'CI/CD Pipelines (GitHub Actions / Jenkins)', category: 'Practical', description: 'Creating automated deployment pipelines linking code commits directly to servers.', recommendedResource: 'DevOps Bootcamp' },
          { name: 'AWS / GCP Solutions Architecture', category: 'Certification', description: 'Professional cloud architecture certifications verifying system design skills.', recommendedResource: 'AWS Certified Solutions Architect - Associate' },
          { name: 'Monitoring (Prometheus / Grafana)', category: 'Practical', description: 'Setting up alert mechanisms, log aggregation, and real-time dashboard tracking.', recommendedResource: 'Grafana Certification Academy' },
          { name: 'Incident Response & Calmness', category: 'Soft Skills', description: 'Remaining composed under stress when critical production servers crash and debugging methodically.', recommendedResource: 'SRE Incident Management books' }
        ],
        careerRoadmapSteps: [
          'Acquire solid Linux fundamentals and learn Bash scripting or Python during your B.Tech.',
          'Understand containerization concepts by deploying your personal portfolio on Docker.',
          'Earn your first major cloud certification (AWS Cloud Practitioner or Solutions Architect).',
          'Learn Terraform and set up a multi-service automated deployment pipeline on GitHub.',
          'Apply for Associate DevOps positions or Cloud Support engineering slots.'
        ],
        fasttrackTips: [
          'The CKA (Certified Kubernetes Administrator) is considered one of the highest-value certifications in the tech space; passing it almost guarantees interviews.',
          'Build an "SRE Portfolio" containing a write-up of how you debugged and fixed a mock high-traffic outage scenario.'
        ]
      },
      {
        id: 'vlsi-ece',
        title: 'VLSI Design & Embedded Systems',
        description: 'Design microchips, model digital circuits, program microcontrollers, and develop firmware for hardware products.',
        globalDemand: {
          countries: ['Taiwan', 'USA', 'Germany', 'South Korea', 'India (Bengaluru)'],
          industries: ['Semiconductors', 'Consumer Electronics', 'Automotive', 'Aerospace'],
          growthRate: '15% CAGR',
          outlook: 'Very High'
        },
        salaryRanges: {
          india: '₹5.5L - ₹18L p.a.',
          global: '$85,000 - $145,000 p.a.'
        },
        targetRoles: [
          { title: 'VLSI Verification Engineer', description: 'Write test benches and verify complex digital layouts using SystemVerilog.' },
          { title: 'Embedded Software Engineer', description: 'Write low-level C code to control hardware microcontrollers and sensors.' },
          { title: 'SoC (System on Chip) Designer', description: 'Map out integrated circuit gates, clock boundaries, and bus architectures.' }
        ],
        skillsMatrix: [
          { name: 'Verilog / SystemVerilog', category: 'Technical', description: 'Hardware description languages used to design and verify digital electronic systems.', recommendedResource: 'IEEE ASIC/FPGA training' },
          { name: 'Universal Verification Methodology (UVM)', category: 'Technical', description: 'Industry-standard structured methodology for verifying complex chip designs.', recommendedResource: 'UVM Academy' },
          { name: 'Embedded C / C++', category: 'Technical', description: 'Writing efficient, memory-constrained programs for real-time operating systems (RTOS).', recommendedResource: 'Modern Embedded Systems Course (Miro Samek)' },
          { name: 'FPGA Prototyping', category: 'Practical', description: 'Synthesizing HDL code and testing digital systems on real FPGA development boards.', recommendedResource: 'Xilinx Vivado tutorials' },
          { name: 'Microcontroller Programming (ARM Cortex)', category: 'Practical', description: 'Interfacing with hardware buses like I2C, SPI, UART, and managing interrupts.', recommendedResource: 'ARM Architecture courses' },
          { name: 'Oscilloscope & Debugging tools', category: 'Practical', description: 'Using physical electronic test equipment to measure signal wave integrity.', recommendedResource: 'Lab practical guides' }
        ],
        careerRoadmapSteps: [
          'Master Digital Logic Design and Computer Architecture modules during your university semesters.',
          'Learn Verilog and program standard digital components (counters, ALUs, state machines).',
          'Practice embedded C programming on cheap microcontrollers like STM32 or ESP32.',
          'Secure an internship at a semiconductor MNC (e.g., Intel, Texas Instruments, Qualcomm).',
          'Choose between digital design, physical design, functional verification, or firmware tracks.'
        ],
        fasttrackTips: [
          'SystemVerilog combined with UVM is the absolute goldmine skill for ECE majors. It has a high learning curve but commands astronomical salaries.',
          'Make a video of your physical electronics projects (e.g., autonomous robots, custom sensory units) and link it in your resume.'
        ]
      }
    ]
  },
  {
    id: 'me-mtech',
    name: 'M.E. / M.Tech',
    category: 'Engineering',
    fullForm: 'Master of Engineering / Technology',
    description: 'An advanced 2-year technical postgraduate degree with rigorous academic and research emphasis, preparing professionals for high-tech engineering sectors and corporate labs.',
    commonSpecializations: ['Artificial Intelligence & Robotics', 'VLSI Design', 'Structural Engineering', 'Thermal Sciences', 'Power Systems'],
    careerPaths: [
      {
        id: 'ai-robotics',
        title: 'AI, Robotics & Autonomous Systems',
        description: 'Design robotic navigation algorithms, implement machine vision, and build automation frameworks for smart factories.',
        globalDemand: {
          countries: ['Japan', 'Germany', 'USA', 'Singapore', 'India'],
          industries: ['Industrial Automation', 'Self-Driving Cars', 'Warehouse Logistics', 'Medical Robotics'],
          growthRate: '25% CAGR',
          outlook: 'Explosive'
        },
        salaryRanges: {
          india: '₹9L - ₹26L p.a.',
          global: '$110,000 - $190,000 p.a.'
        },
        targetRoles: [
          { title: 'Robotics Software Engineer', description: 'Write robot kinematics, sensor fusion algorithms, and motion control routines.' },
          { title: 'Computer Vision Scientist', description: 'Train neural networks for object detection, 3D mapping, and visual SLAM.' },
          { title: 'Control Systems Architect', description: 'Model mechanical behaviors and design stable feedback controllers.' }
        ],
        skillsMatrix: [
          { name: 'Robot Operating System (ROS / ROS2)', category: 'Technical', description: 'The premier open-source middleware suite used to write robotic software.', recommendedResource: 'ROS.org Tutorials' },
          { name: 'C++ Software Engineering', category: 'Technical', description: 'Writing highly performant, low-latency, object-oriented code for real-time systems.', recommendedResource: 'Modern C++ (C++17/20) guides' },
          { name: 'Computer Vision (OpenCV / PyTorch)', category: 'Technical', description: 'Processing camera frames, extracting features, and training neural networks.', recommendedResource: 'Udacity Computer Vision Nanodegree' },
          { name: '3D Kinematics & Dynamics', category: 'Technical', description: 'Calculating joint matrices, inverse kinematics, and inertial forces of physical robotic arms.', recommendedResource: 'Robotics course (John Craig)' },
          { name: 'MATLAB / Simulink Simulation', category: 'Practical', description: 'Modeling multi-body physical systems and simulating complex control loops.', recommendedResource: 'MathWorks Certification' },
          { name: 'Lidar & Sensor Fusion (Kalman Filters)', category: 'Technical', description: 'Combining data from cameras, GPS, IMUs, and laser rangefinders for precise localization.', recommendedResource: 'Sensor Fusion tutorials' }
        ],
        careerRoadmapSteps: [
          'Acquire solid foundations in linear algebra, coordinate transforms, and mechanics.',
          'Learn ROS/ROS2 and simulate a mobile robot navigating in Gazebo environment.',
          'Implement visual SLAM or object tracking code on real camera streams.',
          'Publish your thesis or capstone project in a robotics workshop/conference.',
          'Apply for autonomous systems engineer jobs in major automotive or industrial robotics firms.'
        ],
        fasttrackTips: [
          'Autonomous vehicle companies prioritize candidates who have hands-on experience with ROS2 and C++17. Move away from Python for production robotics roles.',
          'Build a simulated robotic arm in Gazebo that sorts letters, and document the physics equations you used on your GitHub page.'
        ]
      },
      {
        id: 'structural-eng',
        title: 'Advanced Structural Engineering & BIM',
        description: 'Design massive earthquake-resistant skyscrapers, bridges, and oversee Building Information Modeling (BIM) workflows for global design consultancies.',
        globalDemand: {
          countries: ['UAE (Dubai)', 'Saudi Arabia (Neom)', 'UK', 'Australia', 'India'],
          industries: ['Civil Design Consultancies', 'Real Estate conglomerates', 'Metro Rail boards', 'Oil & Gas Infrastructure'],
          growthRate: '8% CAGR',
          outlook: 'Stable'
        },
        salaryRanges: {
          india: '₹5L - ₹14L p.a.',
          global: '$70,000 - $110,000 p.a.'
        },
        targetRoles: [
          { title: 'Structural Analyst / Designer', description: 'Calculate structural loads, wind stresses, and design steel/concrete frames.' },
          { title: 'BIM Coordinator / Manager', description: 'Integrate 3D architectural, structural, and mechanical designs into unified master models.' },
          { title: 'Geotechnical Consultant', description: 'Analyze soil load capacities and design massive underground foundations.' }
        ],
        skillsMatrix: [
          { name: 'STAAD.Pro / ETABS software', category: 'Technical', description: 'Standard industrial finite element analysis programs used to analyze structural designs.', recommendedResource: 'Bentley / CSI Academy certificates' },
          { name: 'Revit Structure & BIM workflows', category: 'Practical', description: 'Modeling smart 3D building elements and coordinating service overlaps.', recommendedResource: 'Autodesk Certified Professional' },
          { name: 'Seismic & Wind Design Codes (IS/Eurocode)', category: 'Technical', description: 'Complying with geographical safety regulations for earthquakes and hurricanes.', recommendedResource: 'Indian Standard codes / Eurocodes' },
          { name: 'Finite Element Method (FEM)', category: 'Technical', description: 'Mathematical formulation to analyze stress points in complex joint models.', recommendedResource: 'FEM courses (MIT OpenCourseWare)' },
          { name: 'Project Management (Primavera P6)', category: 'Practical', description: 'Scheduling timelines, optimizing materials, and calculating project critical paths.', recommendedResource: 'Primavera P6 Certification' }
        ],
        careerRoadmapSteps: [
          'Study concrete structures and steel design modules thoroughly during your postgrad.',
          'Acquire expert efficiency in structural modelers like ETABS or SAP2000.',
          'Get trained in Revit Structure to master standard Building Information Modeling (BIM) techniques.',
          'Secure an internship at leading structural design consultants (e.g., L&T, Ramboll, Atkins).',
          'Acquire professional licensing (Chartered Engineer status) after building up work experience.'
        ],
        fasttrackTips: [
          'Saudi Arabia\'s NEOM project is currently the largest civil engineering playground in the world. Consultancies handling NEOM projects actively look for M.Tech Structural Engineers with expert BIM skills.',
          'Learn basic visual scripting (Dynamo inside Revit) to automate structural layout modifications, an extremely rare and valuable talent.'
        ]
      }
    ]
  },
  {
    id: 'diploma',
    name: 'Diploma (Engineering)',
    category: 'Diploma',
    fullForm: 'Diploma in Engineering',
    description: 'A 3-year professional technical program entered after 10th or 12th standard, focusing heavily on hands-on practical industrial operations, troubleshooting, and site supervisor skills.',
    commonSpecializations: ['Mechanical Engineering', 'Electrical Engineering', 'Civil Engineering', 'Computer Engineering'],
    careerPaths: [
      {
        id: 'industrial-maint',
        title: 'Industrial Automation & Maintenance Engineering',
        description: 'Program industrial PLCs, calibrate automated machinery, maintain assembly robots, and supervise plant floor safety.',
        globalDemand: {
          countries: ['Germany', 'Japan', 'India', 'UAE', 'Singapore'],
          industries: ['Automotive Plants', 'Food & Beverage Packaging', 'Power Generation', 'Heavy Manufacturing'],
          growthRate: '12% CAGR',
          outlook: 'Very High'
        },
        salaryRanges: {
          india: '₹2.8L - ₹6.5L p.a.',
          global: '$45,000 - $75,000 p.a.'
        },
        targetRoles: [
          { title: 'PLC Programmer / Automation Supervisor', description: 'Write ladder logic programs and supervise sensor-actuator grids.' },
          { title: 'Plant Maintenance Technician', description: 'Diagnose faults, replace faulty actuators, and execute preventive repair cycles.' },
          { title: 'Quality Assurance Inspector', description: 'Verify physical tolerances of manufactured items using laser tools.' }
        ],
        skillsMatrix: [
          { name: 'PLC Programming (Siemens / Rockwell)', category: 'Technical', description: 'Writing Ladder Logic and Function Block Diagrams to control factory logic.', recommendedResource: 'Siemens Certified Automation Professional' },
          { name: 'SCADA & HMI Configuration', category: 'Technical', description: 'Designing visual touch panels for operators and logging sensor outputs.', recommendedResource: 'SCADA systems training' },
          { name: 'Hydraulic & Pneumatic Systems', category: 'Technical', description: 'Troubleshooting fluid valves, air compressors, and heavy pressure cylinders.', recommendedResource: 'Industrial Hydraulics hands-on training' },
          { name: 'Industrial Safety (NEBOSH / OSHA)', category: 'Certification', description: 'International occupational safety certificates for supervising dangerous factory zones.', recommendedResource: 'NEBOSH IGC Certificate' },
          { name: 'Electrical Wiring & Troubleshooting', category: 'Practical', description: 'Reading electrical schematics, using multimeters, and tracing signal failures.', recommendedResource: 'Industrial Electrician guides' },
          { name: 'Team Leadership & Supervision', category: 'Soft Skills', description: 'Coordinating shifts of plant workers and explaining safety rules clearly.', recommendedResource: 'Floor Management trainings' }
        ],
        careerRoadmapSteps: [
          'Practice hands-on lab experiments in electrical machines and PLC panels.',
          'Earn certified training in PLC/SCADA programming at an authorized institute.',
          'Obtain basic safety clearance (OSHA or standard Indian factory safety act guidelines).',
          'Join a major manufacturing company (e.g., Maruti Suzuki, Tata Motors, Siemens) as a Diploma Apprentice Trainee (DAT).',
          'Rise to Plant Maintenance Supervisor or move to international manufacturing hubs (especially Germany/Japan).'
        ],
        fasttrackTips: [
          'Germany and Japan are facing acute shortages of hands-on industrial technicians. A diploma combined with German/Japanese language proficiency (N4/B1) is a direct golden ticket to global relocation.',
          'Get certified in NEBOSH safety; safety supervisors in construction/manufacturing are highly sought after in Gulf countries (UAE/Qatar).'
        ]
      },
      {
        id: 'civil-site-super',
        title: 'Civil Construction & Infrastructure Supervision',
        description: 'Supervise on-site concrete pours, handle material quality checks, map elevation profiles, and enforce worker safety rules.',
        globalDemand: {
          countries: ['India', 'UAE', 'Saudi Arabia', 'Qatar', 'Malaysia'],
          industries: ['Metro Rail Construction', 'Highway Infrastructure', 'Real Estate development', 'Port expansion'],
          growthRate: '10% CAGR',
          outlook: 'Stable'
        },
        salaryRanges: {
          india: '₹2.5L - ₹6L p.a.',
          global: '$40,000 - $70,000 p.a.'
        },
        targetRoles: [
          { title: 'Site Supervisor / Junior Engineer (Civil)', description: 'Supervise daily construction execution, coordinate labor shifts, and log material counts.' },
          { title: 'Surveying Officer / Leveller', description: 'Map plot coordinates and elevation gradients using electronic Total Station equipment.' },
          { title: 'Quality Assurance Auditor (Concrete/Soil)', description: 'Perform core compression tests on concrete cubes and verify soil compaction.' }
        ],
        skillsMatrix: [
          { name: 'Total Station Surveying', category: 'Practical', description: 'Using optical-electronic equipment to calculate land coordinates and elevations.', recommendedResource: 'Total Station Hands-on Training' },
          { name: 'AutoCAD Drafting', category: 'Practical', description: 'Drafting 2D structural designs and site layout drawings.', recommendedResource: 'Autodesk AutoCAD Certified' },
          { name: 'Concrete Mix & Laboratory Testing', category: 'Technical', description: 'Performing slump tests, moisture calculations, and concrete strength audits.', recommendedResource: 'Civil Engineering Materials Lab manual' },
          { name: 'Construction Estimating & Costing', category: 'Technical', description: 'Calculating brick counts, steel reinforcement tonnage, and cement bags required.', recommendedResource: 'QS & Estimating manuals' },
          { name: 'Safety Management (OSHA / Indian Codes)', category: 'Technical', description: 'Enforcing safety harnesses, helmet rules, and scaffolding safety measures.', recommendedResource: 'National Safety Council India' }
        ],
        careerRoadmapSteps: [
          'Master Total Station and AutoCAD during your Diploma semesters.',
          'Secure on-site apprenticeships with regional builders or road developers.',
          'Learn to read complex structural reinforcement drawings.',
          'Apply for Junior Engineer (JE) roles in Government departments (SSC JE) or join private contractors.',
          'Acquire Project Supervisor status handling larger infrastructure contracts.'
        ],
        fasttrackTips: [
          'MNCs handling metro rail projects in India look for site-supervisors with hands-on Total Station surveying skills. It is highly valued over theoretical concepts.',
          'Mastering basic MS Project or Primavera planning enables a site supervisor to quickly shift into air-conditioned site planning cabins, boosting salary.'
        ]
      }
    ]
  },
  {
    id: 'ca',
    name: 'CA',
    category: 'Commerce',
    fullForm: 'Chartered Accountant',
    description: 'Regulated by the ICAI, Chartered Accountancy is the gold-standard professional qualification in India for auditing, accounting, corporate finance, and direct/indirect taxation compliance.',
    commonSpecializations: ['Statutory Audit', 'Direct & Indirect Taxation', 'Corporate Finance & Valuation', 'Forensic Audit', 'Insolvency Practice'],
    careerPaths: [
      {
        id: 'ca-auditing-partner',
        title: 'Statutory Auditing & Corporate Advisory',
        description: 'Provide independent assurance on the financial health of listed entities and multinational organizations, ensuring alignment with Indian AS and global IFRS standards.',
        globalDemand: {
          countries: ['India', 'UAE', 'Singapore', 'UK', 'Australia'],
          industries: ['Accounting & Consulting (Big 4)', 'Financial Institutions', 'Multinational Conglomerates'],
          growthRate: '12% CAGR',
          outlook: 'Very High'
        },
        salaryRanges: {
          india: '₹8L - ₹25L p.a.',
          global: '$95,000 - $165,000 p.a.'
        },
        targetRoles: [
          { title: 'Statutory Audit Manager', description: 'Lead enterprise-level statutory audits and sign off on quarterly compliance portfolios.' },
          { title: 'Risk Advisory Partner', description: 'Evaluate corporate internal controls, manage forensic audits, and guide board decisions on risk mitigation.' },
          { title: 'Taxation Consultant', description: 'Formulate corporate tax strategy, handle cross-border transfer pricing, and represent clients before regulatory authorities.' }
        ],
        skillsMatrix: [
          { name: 'Indian Accounting Standards (Ind AS)', category: 'Technical', description: 'Comprehensive understanding of Ind AS, Indian GAAP, and alignment with International Financial Reporting Standards (IFRS).', recommendedResource: 'ICAI Professional Study Material' },
          { name: 'Corporate Tax Law & GST Compliance', category: 'Technical', description: 'In-depth expertise in the Income Tax Act, 1961 and Goods & Services Tax (GST) structures.', recommendedResource: 'NPTEL Corporate Taxation' },
          { name: 'Audit Analytics & Tools (ACL/Alteryx)', category: 'Practical', description: 'Utilizing data analytics platforms to scan millions of ledger transactions for anomalies.', recommendedResource: 'Data Analytics for Auditors Bootcamp' },
          { name: 'Registered Valuer Credential', category: 'Certification', description: 'IBBI Registered Valuer certification for formal asset and business valuations during mergers.', recommendedResource: 'Insolvency and Bankruptcy Board of India' },
          { name: 'Boardroom Presentation', category: 'Soft Skills', description: 'Presenting high-risk audit findings to the board of directors and audit committees objectively.', recommendedResource: 'Executive Presence Seminars' }
        ],
        careerRoadmapSteps: [
          'Clear the CA Intermediate examination and secure articleship in a reputable firm.',
          'Complete 2-3 years of rigorous practical training across audit, tax, and corporate consultancy.',
          'Pass the CA Final examinations and obtain active membership from ICAI.',
          'Secure an executive-level associate role inside Big 4 accounting firms or global corporations.',
          'Advance to Senior Manager, Director, and eventually Partner leading major audit circles.'
        ],
        fasttrackTips: [
          'Combining CA with a Global CPA (US) or ACCA (UK) credential instantly unlocks overseas partner tracks, especially in dynamic hubs like Singapore or the UAE.',
          'Acquiring certifications in Forensic Auditing and ESG Reporting is highly lucrative as modern boardrooms prioritize corporate integrity and green compliance.'
        ]
      },
      {
        id: 'ca-cfo-path',
        title: 'CFO Office & Corporate Finance Advisory',
        description: 'Drive high-level financial planning and analysis (FP&A), treasury operations, mergers and acquisitions (M&A), and corporate fundraising strategies.',
        globalDemand: {
          countries: ['India', 'USA', 'UK', 'Singapore', 'Germany'],
          industries: ['Investment Banking', 'Tech Startups / SaaS', 'Manufacturing Giants', 'Private Equity'],
          growthRate: '15% CAGR',
          outlook: 'Explosive'
        },
        salaryRanges: {
          india: '₹12L - ₹35L p.a.',
          global: '$110,000 - $220,000 p.a.'
        },
        targetRoles: [
          { title: 'Director of Corporate Finance', description: 'Formulate growth strategy, oversee mergers, and structure syndicated debt or equity rounds.' },
          { title: 'Chief Financial Officer (CFO)', description: 'Lead the global finance department, direct investor relations, and guide long-term fiscal policies.' },
          { title: 'Treasury & FX Risk Director', description: 'Protect company balance sheets against foreign exchange volatility using advanced derivatives hedging.' }
        ],
        skillsMatrix: [
          { name: 'Mergers & Acquisitions (M&A) Advisory', category: 'Technical', description: 'Structuring asset purchases, buy-side / sell-side diligence, and post-merger integration strategies.', recommendedResource: 'CFI M&A Modeling Course' },
          { name: 'Corporate Treasury Operations', category: 'Technical', description: 'Managing multi-currency capital structures, commercial paper emissions, and liquidity ratios.', recommendedResource: 'CTP (Certified Treasury Professional)' },
          { name: 'SAP S/4HANA Finance', category: 'Practical', description: 'Industry-standard cloud enterprise resource planning (ERP) platform for advanced financial reporting.', recommendedResource: 'SAP Learning Hub' },
          { name: 'Chartered Financial Analyst (CFA)', category: 'Certification', description: 'Prestigious global credential verifying advanced investment analysis and portfolio management.', recommendedResource: 'CFA Institute Program' },
          { name: 'Negotiation & Investor Relations', category: 'Soft Skills', description: 'Securing multi-million dollar banking facilities and answering questions from institutional shareholders.', recommendedResource: 'Wharton Negotiation Workshops' }
        ],
        careerRoadmapSteps: [
          'Pass CA Final examinations with high scores and gain broad exposure to corporate taxation.',
          'Acquire deep competency in financial modeling, valuation techniques, and advanced corporate treasury.',
          'Enroll in the CFA program (Aiming for Level 2/3) to enhance global asset-management authority.',
          'Join the corporate development, investment banking, or corporate treasury wing of a major enterprise.',
          'Rise through the ranks from Controller to Vice President of Finance, and ultimately Chief Financial Officer (CFO).'
        ],
        fasttrackTips: [
          'High-growth tech startups actively recruit young CAs who possess a keen understanding of equity structures, ESOP pool formulation, and venture debt mechanics.',
          'Understand ESG financial disclosures, as this is currently the fastest-growing treasury compliance domain globally.'
        ]
      }
    ]
  },
  {
    id: 'cs',
    name: 'CS',
    category: 'Commerce',
    fullForm: 'Company Secretary',
    description: 'Regulated by the ICSI, Company Secretaryship is the premier professional qualification for ensuring robust corporate governance, board advisory, legal compliance, and regulatory alignments in India.',
    commonSpecializations: ['Corporate Governance', 'Securities Laws', 'Insolvency & Bankruptcy', 'Corporate Restructuring', 'Foreign Exchange Regulations (FEMA)'],
    careerPaths: [
      {
        id: 'cs-board-advisory',
        title: 'Corporate Governance & Board Advisory',
        description: 'Serve as the key advisor to the board of directors, ensuring that company decisions strictly comply with corporate laws, listing guidelines, and ethical benchmarks.',
        globalDemand: {
          countries: ['India', 'UK', 'Singapore', 'UAE', 'Australia'],
          industries: ['Listed Corporations', 'Legal & Secretarial Firms', 'Financial Regulators (SEBI/NSE)'],
          growthRate: '8% CAGR',
          outlook: 'Stable'
        },
        salaryRanges: {
          india: '₹6L - ₹18L p.a.',
          global: '$80,000 - $140,000 p.a.'
        },
        targetRoles: [
          { title: 'Company Secretary & Legal Head', description: 'Maintain secretarial records, convene board meetings, and certify corporate compliance filings.' },
          { title: 'Compliance Director', description: 'Monitor and audit corporate procedures to ensure 100% compliance with local and international business regulations.' },
          { title: 'Corporate Governance Consultant', description: 'Consult external boards on ESG mandates, diversity criteria, and institutional shareholder policies.' }
        ],
        skillsMatrix: [
          { name: 'SEBI Regulations & Companies Act, 2013', category: 'Technical', description: 'Comprehensive knowledge of statutory filing requirements, shareholder privileges, and stock exchange listing rules (LODR).', recommendedResource: 'ICSI Study Materials' },
          { name: 'Legal Drafting & Minute Writing', category: 'Practical', description: 'Drafting clear, bulletproof corporate resolutions, legal representations, and board minutes.', recommendedResource: 'ICSI Legal Drafting Guides' },
          { name: 'MNC Compliance Systems (Diligent/Thomson Reuters)', category: 'Practical', description: 'Operating digital entity management and board portal software platforms.', recommendedResource: 'Corporate Governance Tech training' },
          { name: 'Insolvency Professional Certification', category: 'Certification', description: 'Cleared exam from the IBBI to act as a resolution professional during corporate debt restructurings.', recommendedResource: 'Insolvency and Bankruptcy Board of India (IBBI)' },
          { name: 'Diplomacy & Boardroom Presence', category: 'Soft Skills', description: 'Navigating sensitive board conflicts, managing shareholder dialogues, and representing legal boundaries calmly.', recommendedResource: 'Executive Leadership Institutes' }
        ],
        careerRoadmapSteps: [
          'Pass the CS Executive exams and register for mandatory practical training.',
          'Complete 15-21 months of internship under a practicing Company Secretary or inside a listed company.',
          'Clear the CS Professional program and obtain official membership from the ICSI.',
          'Join a public listed corporation as an Assistant/Deputy Company Secretary.',
          'Progress to Chief Company Secretary & Compliance Officer working directly with the CEO and Board.'
        ],
        fasttrackTips: [
          'MNCs highly value the "Chartered Secretary" status. Clear the CGI (Chartered Governance Institute, UK) exam for smooth pathways into the UK, Canada, Australia, and Singapore.',
          'Acquire expertise in Foreign Exchange Management Act (FEMA) laws, as international joint ventures look for CS professionals to handle foreign direct investment (FDI) entries.'
        ]
      }
    ]
  },
  {
    id: 'mbbs',
    name: 'MBBS',
    category: 'Science',
    fullForm: 'Bachelor of Medicine, Bachelor of Surgery',
    description: 'The foundational 5.5-year professional medical undergraduate degree in India, encompassing rigorous clinical rotations, clinical diagnostics, pharmacology, and medical ethics, regulated by the National Medical Commission (NMC).',
    commonSpecializations: ['General Medicine', 'Surgery & Emergency Medicine', 'Pediatrics', 'Obstetrics & Gynecology', 'Hospital Medicine'],
    careerPaths: [
      {
        id: 'mbbs-clinical-practice',
        title: 'Clinical Practice & Emergency Medicine',
        description: 'Provide primary medical care, diagnose complex internal illnesses, manage life-saving emergency rooms, or oversee general health clinics.',
        globalDemand: {
          countries: ['India', 'UK', 'Australia', 'Ireland', 'UAE'],
          industries: ['Corporate Hospital Networks', 'Primary Healthcare Centers', 'Emergency Medical Services'],
          growthRate: '12% CAGR',
          outlook: 'Very High'
        },
        salaryRanges: {
          india: '₹8L - ₹16L p.a.',
          global: '$120,000 - $180,000 p.a.'
        },
        targetRoles: [
          { title: 'Emergency Room Medical Officer', description: 'Assess and stabilize critical trauma or acute cardiac cases on the frontlines.' },
          { title: 'General Practitioner (Physician)', description: 'Diagnose outpatient illnesses, manage chronic conditions, and prescribe pharmacological regimens.' },
          { title: 'Clinical Trials Investigator', description: 'Monitor patient safety and dose reactions during clinical research phases in corporate hospitals.' }
        ],
        skillsMatrix: [
          { name: 'Clinical Diagnostics & Patient Assessment', category: 'Technical', description: 'Taking comprehensive clinical history, interpreting lab assays, and executing accurate physical exams.', recommendedResource: 'Macleod Clinical Examination Manual' },
          { name: 'Advanced Cardiac Life Support (ACLS)', category: 'Practical', description: 'Practical mastery of cardiac resuscitation, airway management, and emergency pharmacology.', recommendedResource: 'American Heart Association (AHA)' },
          { name: 'Electronic Medical Records (Epic/Cerner)', category: 'Practical', description: 'Navigating hospital-wide digital charts, logging symptoms, and ordering prescriptions.', recommendedResource: 'EMR System Certifications' },
          { name: 'PLAB / USMLE / AMC Clearing', category: 'Certification', description: 'Passing medical licensure exams for global practice (UK PLAB, USA USMLE, Australia AMC).', recommendedResource: 'GMC / ECFMG portal portals' },
          { name: 'Empathy & Bedside Manners', category: 'Soft Skills', description: 'Communicating delicate diagnoses clearly and compassionately to patients and distressed families.', recommendedResource: 'Clinical Communication Workshops' }
        ],
        careerRoadmapSteps: [
          'Complete the 4.5 years of medical study followed by the mandatory 1-year rotatory internship (CRRI) in a recognized medical college.',
          'Obtain active state and national medical registrations from the National Medical Commission (NMC).',
          'Gain hands-on clinical confidence in multi-specialty corporate hospitals or emergency rooms.',
          'Enroll in licensure preparation modules if targeting foreign medical streams (e.g. PLAB, USMLE).',
          'Practice as a Senior Medical Officer or prepare for specialization exams (NEET PG / INI-CET).'
        ],
        fasttrackTips: [
          'The UK National Health Service (NHS) has a highly structured, accelerated pathway for Indian MBBS graduates who clear PLAB exams, providing excellent clinical progression.',
          'Obtaining a certification in Hospital Administration or Health Informatics is an excellent pathway to high-paying clinical lead positions in healthcare MNCs.'
        ]
      }
    ]
  },
  {
    id: 'md',
    name: 'MD',
    category: 'Science',
    fullForm: 'Doctor of Medicine',
    description: 'A prestigious 3-year postgraduate specialist medical degree in India. Focuses on advanced diagnostic methodologies, therapeutic medicine, specialized patient care, and clinical research.',
    commonSpecializations: ['Internal Medicine', 'Pediatrics', 'Radiology', 'Cardiology', 'Dermatology', 'Pulmonology'],
    careerPaths: [
      {
        id: 'md-specialist-consultant',
        title: 'Specialist Medical Consultant & Hospital Practice',
        description: 'Provide high-level specialty clinical consultations, perform advanced diagnostic procedures, design targeted oncology/cardiology treatment plans, and lead department research.',
        globalDemand: {
          countries: ['USA', 'UK', 'UAE', 'Singapore', 'Canada', 'India'],
          industries: ['Tier-1 Super-Specialty Hospitals', 'Clinical Research Centers', 'Medical Academies'],
          growthRate: '15% CAGR',
          outlook: 'Very High'
        },
        salaryRanges: {
          india: '₹15L - ₹40L p.a.',
          global: '$200,000 - $350,000 p.a.'
        },
        targetRoles: [
          { title: 'Senior Specialist Consultant', description: 'Formulate definitive diagnostic and therapeutic strategies for complex multi-system disorders.' },
          { title: 'Specialist Department Head', description: 'Oversee ICU operations, supervise junior medical residents, and manage clinical quality benchmarks.' },
          { title: 'Clinical Trial Advisor', description: 'Advise pharmaceutical developers on trial protocol safety and efficacy metrics.' }
        ],
        skillsMatrix: [
          { name: 'Advanced Specialty Diagnostics (MRI/CT/EEG)', category: 'Technical', description: 'Analyzing complex radiological scans, hemodynamic reports, and electrophysiological readings.', recommendedResource: 'Specialty Residency Manuals' },
          { name: 'Interventional Medicine Procedures', category: 'Practical', description: 'Performing specialized bedside techniques (e.g., lumbar punctures, central line insertions, biopsies).', recommendedResource: 'Supervised Hospital Residency' },
          { name: 'Medical Tele-Health platforms', category: 'Practical', description: 'Managing remote critical care and tele-consultations across global digital networks.', recommendedResource: 'Telemedicine Association Course' },
          { name: 'MRCP / MRCPCH Credentials', category: 'Certification', description: 'Passing Royal College (UK) specialty board examinations to achieve international medical standing.', recommendedResource: 'Royal College of Physicians, UK' },
          { name: 'Clinical Team Leadership', category: 'Soft Skills', description: 'Coordinating large multi-disciplinary teams (surgeons, nurses, therapists) under high-stress scenarios.', recommendedResource: 'Healthcare Leadership Courses' }
        ],
        careerRoadmapSteps: [
          'Earn your MBBS degree and clear NEET PG/INI-CET with exceptional percentile scores.',
          'Complete 3 years of residency and submit a research dissertation to secure the MD degree.',
          'Obtain specialist physician registrations and build diagnostic caseload portfolios.',
          'Acquire international corporate credentials or clear country-specific board equivalencies.',
          'Practice as a Senior Consultant Physician, Department Chief, or pursue superspecialization (DM / Fellowships).'
        ],
        fasttrackTips: [
          'Singapore and Middle Eastern countries actively recruit Indian MD specialists with MRCP (UK) credentials directly, bypass many local entry-level restrictions, and pay lucrative packages.',
          'Publishing research papers in indexed journals (PubMed/Scopus) during your residency establishes global medical authority, crucial for research fellowship selections.'
        ]
      }
    ]
  },
  {
    id: 'phd',
    name: 'Ph.D.',
    category: 'Science',
    fullForm: 'Doctor of Philosophy',
    description: 'The highest academic doctorate degree, emphasizing original scientific, humanitarian, or pedagogical research, thesis publication, and advanced academic leadership across various streams.',
    commonSpecializations: ['STEM (Science/Tech/Engineering)', 'Education & Pedagogy', 'Economics & Policy Studies', 'Biomedical & Life Sciences', 'Humanities & Social Sciences'],
    careerPaths: [
      {
        id: 'phd-academic-administration',
        title: 'Academic Administration & Higher Education Leadership',
        description: 'Direct university strategy, lead academic research departments, set curriculum standards, mentor doctoral candidates, and publish high-impact peer-reviewed journals.',
        globalDemand: {
          countries: ['USA', 'UK', 'Singapore', 'Australia', 'India', 'Germany'],
          industries: ['Global Universities', 'Higher Education Boards', 'EdTech Think-Tanks'],
          growthRate: '8% CAGR',
          outlook: 'Stable'
        },
        salaryRanges: {
          india: '₹12L - ₹28L p.a.',
          global: '$100,000 - $180,000 p.a.'
        },
        targetRoles: [
          { title: 'University Professor & Supervisor', description: 'Teach advanced postgrad courses and supervise doctoral research candidates.' },
          { title: 'Academic Dean of Department', description: 'Govern departmental budgets, faculty appointments, research grants, and university curriculum alignments.' },
          { title: 'Education Policy Architect', description: 'Design outcome-based learning strategies and pedagogy guidelines for national educational systems.' }
        ],
        skillsMatrix: [
          { name: 'Grant Proposal & Proposal Writing', category: 'Technical', description: 'Securing multi-million dollar research grants from bodies like DST, CSIR, or international foundations.', recommendedResource: 'Research Grant Writing Handbooks' },
          { name: 'Outcome-Based Curriculum Design', category: 'Technical', description: 'Structuring academic programs, course syllabus grids, and pedagogical frameworks.', recommendedResource: 'Harvard Case Method Seminar' },
          { name: 'Quantitative & Qualitative Analysis (R/SPSS/NVivo)', category: 'Practical', description: 'Mastering numerical data processing, thematic coding, and statistical model formulations.', recommendedResource: 'SAGE Qualitative Research Portal' },
          { name: 'UGC NET-JRF / CSIR Fellowship', category: 'Certification', description: 'Top-tier Indian national eligibility credentials proving teaching and research capabilities.', recommendedResource: 'NTA Exam Portals' },
          { name: 'Mentorship & Conflict Resolution', category: 'Soft Skills', description: 'Guiding doctoral scholars, resolving research disputes, and chairing peer-review circles.', recommendedResource: 'Academic Counseling Seminars' }
        ],
        careerRoadmapSteps: [
          'Clear JRF exams during postgrad (M.Sc/M.Tech/M.Com/M.A) and join a tier-1 university.',
          'Complete course-work, design research methodology, and execute 4-5 years of original research.',
          'Publish multiple high-impact research papers in Scopus / ABDC indexed peer-reviewed journals.',
          'Formulate and defend your doctoral thesis, obtaining the Ph.D. degree.',
          'Start as an Assistant Professor, progress to Associate, Full Professor, and Dean of Academics.'
        ],
        fasttrackTips: [
          'Acquiring a Postdoctoral Fellowship (PostDoc) in Ivy League or top European research labs instantly places you on accelerated tenure tracks globally.',
          'Familiarize yourself with digital learning suites, adaptive learning tech, and hybrid pedagogy models, as top modern business and tech schools heavily seek these skills.'
        ]
      },
      {
        id: 'phd-industrial-research',
        title: 'Industrial Research & Corporate R&D Lead',
        description: 'Drive high-tech engineering laboratories, lead pharmaceutical formulation discoveries, or publish economic forecasts for global policy think-tanks.',
        globalDemand: {
          countries: ['USA', 'Switzerland', 'Germany', 'Japan', 'Singapore', 'India'],
          industries: ['Deep-Tech & AI Labs', 'Pharmaceutical & Biotech MNCs', 'Economic Policy Think-Tanks'],
          growthRate: '18% CAGR',
          outlook: 'High'
        },
        salaryRanges: {
          india: '₹14L - ₹32L p.a.',
          global: '$120,000 - $210,000 p.a.'
        },
        targetRoles: [
          { title: 'Principal Research Scientist', description: 'Lead deep-tech, artificial intelligence, or material science innovations for corporate product lines.' },
          { title: 'Think-Tank Policy Consultant', description: 'Draft strategic whitepapers on global trade, economic policies, or environmental targets for bodies like the World Bank.' },
          { title: 'Chief Scientific Officer (CSO)', description: 'Direct corporate scientific vision, oversee laboratory infrastructure, and manage patent filing pipelines.' }
        ],
        skillsMatrix: [
          { name: 'Patent Drafting & Intellectual Property (IP)', category: 'Technical', description: 'Structuring patent applications, mapping claims, and managing prior-art searches.', recommendedResource: 'WIPO Patent Academy' },
          { name: 'Deep Domain Technical Synthesis', category: 'Technical', description: 'Unrivaled expertise in specialized domains like Natural Language Processing, Organic Formulation, or Econometric Modeling.', recommendedResource: 'Subject Matter Reference Manuals' },
          { name: 'Laboratory Automation Systems', category: 'Practical', description: 'Operating advanced mass spectrometry, high-performance computing clusters, or automated analytical lines.', recommendedResource: 'Industrial Lab Training' },
          { name: 'Project Management Professional (PMP)', category: 'Certification', description: 'Global credential verifying standard corporate project lifecycle management.', recommendedResource: 'Project Management Institute (PMI)' },
          { name: 'Cross-functional Collaboration', category: 'Soft Skills', description: 'Translating highly complex mathematical or laboratory discoveries into clear business benefits for corporate executives.', recommendedResource: 'Corporate Leadership Bootcamps' }
        ],
        careerRoadmapSteps: [
          'Structure your doctoral research with an emphasis on practical industrial applications or patents.',
          'Secure high-value corporate-sponsored research fellowships or industrial internships.',
          'Build strong cross-disciplinary knowledge connecting science, engineering, or economics with market outcomes.',
          'Join corporate laboratories, R&D departments, or international think-tanks as a Senior Researcher.',
          'Advance to Lead Scientist, Research Director, and ultimately Chief Scientific Officer (CSO).'
        ],
        fasttrackTips: [
          'PhDs in Machine Learning/AI, Quantitative Finance, and Immunology are currently in extreme global demand. Tech firms like Google, Microsoft, or Pfizer hire these graduates directly into high-paying executive research tracks.',
          'Understand corporate project execution metrics (like agile, sprints, and quarterly budgets) to stand out from purely academic scholars in job interviews.'
        ]
      }
    ]
  }
];
