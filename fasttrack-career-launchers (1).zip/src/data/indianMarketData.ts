export interface IndianMarketScope {
  outlook: 'Explosive' | 'Very High' | 'High' | 'Stable';
  hiringHubs: string[];
  prominentEmployers: string[];
  marketTrends: string;
  demandDrivers: string[];
}

export const indianMarketScopeData: Record<string, IndianMarketScope> = {
  'corp-accounting': {
    outlook: 'High',
    hiringHubs: ['Mumbai', 'Bengaluru', 'Gurugram', 'Chennai', 'Pune', 'Hyderabad'],
    prominentEmployers: ['PwC India', 'EY', 'Deloitte', 'KPMG', 'Genpact', 'Accenture', 'Tata Motors', 'Reliance Industries'],
    marketTrends: 'The ongoing expansion of Global Capability Centers (GCCs) in India has created an unprecedented demand for accounting experts. With robust regulatory oversight (GST, Income Tax audits, and Ind AS alignments), skilled accountants who can navigate complex ERPs are extremely valued.',
    demandDrivers: ['Rapid expansion of multinational shared services (GCCs)', 'Digitized GST & E-invoicing frameworks', 'Increased compliance focus post-NFRA audits']
  },
  'investment-banking': {
    outlook: 'Very High',
    hiringHubs: ['Mumbai (BKC/Lower Parel)', 'Bengaluru', 'Gurugram', 'Hyderabad'],
    prominentEmployers: ['Goldman Sachs India', 'JPMorgan Chase', 'Kotak Mahindra Capital', 'ICICI Securities', 'HDFC Bank', 'Avendus Capital', 'Motilal Oswal', 'Zerodha'],
    marketTrends: 'India is experiencing an explosive growth in retail investment participation, venture capital inflows, and IPO listings. Domestic investment banking boutiques and wealth management services are actively recruiting to handle mid-market deals and high-net-worth individual portfolios.',
    demandDrivers: ['Record retail investment via Mutual Funds & SIPs', 'Booming tech and startup IPO markets on NSE/BSE', 'Robust private equity and venture capital deal-making']
  },
  'academic-research': {
    outlook: 'Stable',
    hiringHubs: ['Delhi NCR', 'Pune', 'Bengaluru', 'Kolkata', 'Chennai', 'Ahmedabad'],
    prominentEmployers: ['Delhi University', 'Christ University', 'Symbiosis International', 'Lovely Professional University (LPU)', 'Amity University', 'Sharda University'],
    marketTrends: 'Under the National Education Policy (NEP) 2020, there is a major focus on research-based curriculum and active commerce departments. Qualified M.Com/Ph.D. degree holders who clear the UGC NET-JRF have steady recruitment pipelines for Assistant Professor tenures across expanding private and public institutes.',
    demandDrivers: ['National Education Policy (NEP) 2020 reforms', 'Proliferation of private universities and business schools', 'Higher education research grants and academic upgrading']
  },
  'treasury-management': {
    outlook: 'High',
    hiringHubs: ['Mumbai', 'Gurugram', 'Bengaluru', 'Chennai', 'Pune'],
    prominentEmployers: ['Reliance Industries Treasury', 'Aditya Birla Group', 'Tata Group Treasury', 'ICICI Bank', 'Axis Bank Treasury', 'HDFC Bank', 'L&T Corporate Treasury'],
    marketTrends: 'Large Indian MNCs are expanding globally, and the volatility of the Rupee (INR) against global currencies requires advanced treasury teams. Professionals handling cash flow management, hedging, liquid investment deployment, and debt structuring are highly compensated.',
    demandDrivers: ['Global expansion and multi-currency trades by Indian conglomerates', 'Volatile FX environment requiring continuous risk hedging', 'Adoption of advanced automated corporate treasury management systems']
  },
  'software-dev-bsc': {
    outlook: 'Very High',
    hiringHubs: ['Bengaluru', 'Hyderabad', 'Pune', 'Chennai', 'Noida', 'Kolkata'],
    prominentEmployers: ['TCS (Ignite Program)', 'Infosys', 'Cognizant', 'Wipro', 'HCLTech', 'Tech Mahindra', 'Zoho Corporation', 'LTIMindtree'],
    marketTrends: 'Indian IT service majors run major recruitment initiatives (such as TCS Smart Anst & Wipro WASE/WIMS) specifically to hire and train B.Sc Computer Science and BCA graduates, enabling them to earn master\'s degrees while working in software developer tracks.',
    demandDrivers: ['Massive service-sector transition to cloud and custom web applications', 'Cost-effective talent sourcing programs by major IT employers', 'SaaS startup growth seeking agile programmers']
  },
  'biotech-lab': {
    outlook: 'High',
    hiringHubs: ['Hyderabad (Genome Valley)', 'Bengaluru', 'Pune', 'Ahmedabad', 'Chennai'],
    prominentEmployers: ['Biocon', 'Syngene International', 'Dr. Reddy\'s Laboratories', 'Serum Institute of India', 'Bharat Biotech', 'Lupin', 'Piramal Pharma'],
    marketTrends: 'India\'s rise as a global biosimilar manufacturing power and the expansion of clinical research organizations (CROs) have driven a steady demand for laboratory technicians, research assistants, and bioprocess controllers.',
    demandDrivers: ['Surge in global biosimilar approvals and clinical trials', 'Make in India initiatives for medical devices & active ingredients', 'Increased funding in preventive healthcare & diagnostic research']
  },
  'data-science': {
    outlook: 'Explosive',
    hiringHubs: ['Bengaluru', 'Hyderabad', 'Gurugram', 'Mumbai', 'Pune', 'Chennai'],
    prominentEmployers: ['Fractal Analytics', 'Mu Sigma', 'Tiger Analytics', 'Flipkart', 'Ola', 'Reliance Jio', 'Target India', 'Paytm', 'Swiggy', 'Zomato'],
    marketTrends: 'India is a leading destination for data analytics, hosting over 50% of the world\'s analytics outsourcing market. Companies are heavily recruiting M.Sc/M.Tech specialists with strong mathematical background for high-paying roles in predictive analytics, logistics optimization, and ML pipelines.',
    demandDrivers: ['Data-driven consumer insights in Indian retail and e-commerce', 'Outsourced analytical operations from US/EU firms to Indian analytics giants', 'Rapid deployment of business intelligence tools across MSMEs']
  },
  'r-d-chemist': {
    outlook: 'High',
    hiringHubs: ['Ankleshwar (Gujarat)', 'Vapi', 'Hyderabad', 'Pune', 'Mumbai', 'Visakhapatnam'],
    prominentEmployers: ['Cipla', 'Sun Pharmaceutical', 'Lupin', 'Reliance Petrochemicals', 'Asian Paints', 'Pidilite Industries', 'Aurobindo Pharma', 'Divi\'s Laboratories'],
    marketTrends: 'Chemical and API (Active Pharmaceutical Ingredient) manufacturing is undergoing a significant expansion due to global "China Plus One" supply strategies. Quality control, green chemistry R&D, and regulatory affairs are major secure employment domains in the country.',
    demandDrivers: ['Domestic API manufacturing push and government PLI schemes', 'Expanding paint, adhesive, and petrochemical industries in India', 'Stringent international regulatory audits (USFDA, EMA) requiring skilled QC analysts']
  },
  'cloud-devops': {
    outlook: 'Explosive',
    hiringHubs: ['Bengaluru', 'Hyderabad', 'Pune', 'Noida', 'Chennai', 'Mumbai', 'Kolkata'],
    prominentEmployers: ['Amazon Web Services (AWS) India', 'Microsoft India', 'Google Cloud India', 'Wipro', 'Accenture India', 'Cognizant', 'HCLTech', 'Tech Mahindra', 'Reliance Jio', 'Freshworks'],
    marketTrends: 'Virtually all Indian enterprise sectors, including FinTech, EduTech, and retail, have migrated to the cloud. Certified AWS, Azure, or GCP DevOps engineers who can implement CI/CD pipelines, optimize server costs, and maintain zero-downtime microservices command stellar premium salaries.',
    demandDrivers: ['Enterprise-wide transition to multi-cloud architectures', 'Explosive growth of SaaS startups in India', 'Adoption of containerization (Kubernetes, Docker) for high-traffic apps']
  },
  'vlsi-ece': {
    outlook: 'Very High',
    hiringHubs: ['Bengaluru', 'Noida', 'Hyderabad', 'Pune', 'Chennai'],
    prominentEmployers: ['Intel India', 'Texas Instruments', 'Qualcomm India', 'NXP Semiconductors', 'MediaTek India', 'Wipro VLSI', 'Tata Electronics', 'Sankalp Semiconductor'],
    marketTrends: 'With the launch of the India Semiconductor Mission (ISM) and major investments in wafer fabrication and packaging units, VLSI design has emerged as one of the most elite engineering domains in India. Demand for ECE graduates with RTL design and verification skills is at an all-time high.',
    demandDrivers: ['Government incentives (PLI) for local semiconductor manufacturing', 'Establishment of global chip design houses inside tier-1 Indian cities', '5G rollout and automotive embedded systems expansion']
  },
  'ai-robotics': {
    outlook: 'Explosive',
    hiringHubs: ['Bengaluru', 'Hyderabad', 'Gurugram', 'Pune', 'Chennai', 'Mumbai'],
    prominentEmployers: ['Google DeepMind India', 'NVIDIA India', 'Adobe Research', 'Ola Electric', 'GreyOrange Robotics', 'TCS Research', 'Infosys AI Labs', 'Skan.ai', 'Subtle Medical'],
    marketTrends: 'AI research and advanced automation are growing at a rapid pace in India. Tech firms are recruiting M.Tech and Ph.D. degree holders for custom deep learning model building, conversational AI, computer vision in supply chains, and industrial warehouse robotics.',
    demandDrivers: ['Integration of Generative AI across digital products and services', 'Demand for smart warehouse robotics in e-commerce fulfillment', 'Corporate investment in proprietary AI research and patent creations']
  },
  'structural-eng': {
    outlook: 'Very High',
    hiringHubs: ['Mumbai', 'Delhi NCR', 'Bengaluru', 'Hyderabad', 'Chennai', 'Pune'],
    prominentEmployers: ['Larsen & Toubro (L&T)', 'Tata Consulting Engineers', 'AFCONS Infrastructure', 'GMR Group', 'National Highways Authority of India (NHAI) consultants', 'Shapoorji Pallonji', 'DLF'],
    marketTrends: 'India is in the middle of a historic infrastructure boom. Mega-projects including multi-lane expressways, bullet trains, metro grids across tier-2 cities, smart cities, and new international airports require structural design specialists to construct heavy, resilient structures.',
    demandDrivers: ['Gati Shakti national master plan and heavy government capital expenditure', 'Urban high-rise residential boom and industrial corridors', 'Modernization of railway networks, bridge building, and marine ports']
  },
  'industrial-maint': {
    outlook: 'Very High',
    hiringHubs: ['Pune (Chakan/Bhosari)', 'Chennai (Sriperumbudur)', 'Ahmedabad (Sanand)', 'NCR (Manesar/Gurugram)', 'Jamshedpur', 'Coimbatore'],
    prominentEmployers: ['Tata Motors', 'Maruti Suzuki India', 'Siemens India', 'ABB India', 'Bosch India', 'Schneider Electric', 'L&T Heavy Engineering', 'Mahindra & Mahindra'],
    marketTrends: 'As factories embrace Industry 4.0, lines are becoming heavily automated. Diploma holders who have hands-on practical skills in PLC (Programmable Logic Controllers), SCADA, sensor diagnostics, and preventative robotic line maintenance are essential for keeping manufacturing plants running without halts.',
    demandDrivers: ['The "Make in India" initiative bringing automotive & electronics manufacturing', 'Widespread adoption of automation and robotics in factory assembly lines', 'Demand for highly specialized technical technicians over general workforce']
  },
  'civil-site-super': {
    outlook: 'High',
    hiringHubs: ['Mumbai MMR', 'Bengaluru', 'Delhi NCR', 'Pune', 'Chennai', 'Hyderabad'],
    prominentEmployers: ['DLF', 'Godrej Properties', 'Sobha Developers', 'Shapoorji Pallonji Construction', 'L&T Construction', 'Prestige Group', 'Tata Housing'],
    marketTrends: 'The housing and commercial real estate market in major Indian metros is experiencing robust development. Diploma holders in civil engineering are highly sought after to serve as the critical link on-site, supervising labor, reviewing structural drawings, and enforcing strict material quality controls.',
    demandDrivers: ['Booming premium and affordable housing markets across metros', 'Expansion of corporate tech parks and warehousing hubs in India', 'Focus on construction safety compliance and real estate regulatory frameworks (RERA)']
  },
  'ca-auditing-partner': {
    outlook: 'Explosive',
    hiringHubs: ['Mumbai', 'Gurugram', 'Bengaluru', 'Kolkata', 'Chennai', 'Hyderabad', 'Ahmedabad'],
    prominentEmployers: ['Deloitte India', 'EY India', 'KPMG India', 'PwC India', 'Haribhakti & Co.', 'BDO India', 'Grant Thornton India', 'Singhi & Co.'],
    marketTrends: 'The complexity of financial regulations under the National Financial Reporting Authority (NFRA), GST expansion, and mandatory corporate governance rules have made CAs highly sought after. Statutory auditing, risk advisory, and corporate taxation remain extremely lucrative career paths with partner tracks.',
    demandDrivers: ['Stringent corporate audits and NFRA regulatory guidelines', 'Ever-evolving Direct & Indirect tax codes including GST', 'MNC operations establishing complex subsidiary operations in India']
  },
  'ca-cfo-path': {
    outlook: 'Explosive',
    hiringHubs: ['Mumbai', 'Bengaluru', 'Delhi NCR', 'Pune', 'Hyderabad'],
    prominentEmployers: ['Unicorn Startups (Razorpay, CRED, Ola)', 'Tata Sons', 'Reliance Industries', 'Aditya Birla Group', 'Peak XV Partners', 'Matrix Partners India', 'Invest India'],
    marketTrends: 'Experienced CAs who possess a keen understanding of fundraising, valuation, corporate development, and risk hedging are being recruited directly into the CFO Offices of high-growth tech startups and legacy conglomerates. This role combines financial governance with long-term business strategy.',
    demandDrivers: ['Venture capital and private equity exits requiring compliance readiness', 'Corporate mergers, acquisitions, and consolidated entity restructurings', 'Transition of mid-sized Indian firms into publicly listed entities']
  },
  'cs-board-advisory': {
    outlook: 'High',
    hiringHubs: ['Mumbai', 'Delhi NCR', 'Bengaluru', 'Chennai', 'Hyderabad', 'Kolkata'],
    prominentEmployers: ['NSE/BSE Listed Corporations', 'Shardul Amarchand Mangaldas', 'Cyril Amarchand Mangaldas', 'AZB & Partners', 'Securities and Exchange Board of India (SEBI)', 'ICSI Advisory Hubs'],
    marketTrends: 'With SEBI actively tightening the listing obligations and disclosure requirements (LODR), insider trading monitoring, and ESG disclosures, public corporations and large private entities cannot operate without a qualified CS. They serve as the legal anchor for the board, ensuring zero regulatory defaults.',
    demandDrivers: ['Tighter SEBI LODR rules and mandatory secretarial audits', 'Active corporate ESG reporting and corporate social responsibility (CSR) alignments', 'Surge in domestic joint-ventures and foreign entity compliance setups in India']
  },
  'mbbs-clinical-practice': {
    outlook: 'Explosive',
    hiringHubs: ['Pan-India (Metros, Tier-2, Tier-3 cities & Rural wellness centers)'],
    prominentEmployers: ['Apollo Hospitals', 'Fortis Healthcare', 'Max Healthcare', 'Manipal Hospitals', 'National Health Mission (NHM)', 'Naranyana Health', 'Aster DM Healthcare'],
    marketTrends: 'India faces a critical doctor-to-patient ratio deficit. The rapid expansion of corporate hospital networks, private diagnostics clinics, and government insurance programs (like Ayushman Bharat PM-JAY) guarantees immediate and highly secure employment for MBBS graduates nationwide.',
    demandDrivers: ['Ayushman Bharat and public health insurance coverage expansions', 'Investments in corporate multi-specialty healthcare infrastructures', 'Growing patient preference for institutionalized corporate clinical setups']
  },
  'md-specialist-consultant': {
    outlook: 'Explosive',
    hiringHubs: ['Pan-India (Concentrated in Tier-1 and Tier-2 hospital networks)'],
    prominentEmployers: ['Medanta - The Medicity', 'Kokilaben Dhirubhai Ambani Hospital', 'Apollo Group of Hospitals', 'Fortis Healthcare', 'All India Institute of Medical Sciences (AIIMS)', 'Max Super Speciality Hospitals'],
    marketTrends: 'As lifestyle diseases, chronic illnesses, and medical tourism grow in India, MD specialists in fields like Internal Medicine, Cardiology, Radiology, Dermatology, and Pulmonology are facing extreme demand. They lead diagnostics, manage critical ICUs, and command significant premium clinical shares.',
    demandDrivers: ['Rise of chronic non-communicable and lifestyle disorders', 'Growing medical tourism industry in India due to high-quality low-cost clinical treatments', 'Expansion of advanced diagnostics and tertiary medical centers']
  },
  'phd-academic-administration': {
    outlook: 'Stable',
    hiringHubs: ['Pune', 'Bengaluru', 'Delhi NCR', 'Chennai', 'Hyderabad', 'Kolkata'],
    prominentEmployers: ['Indian Institutes of Technology (IITs)', 'Indian Institutes of Management (IIMs)', 'Indian Institute of Science (IISc)', 'BITS Pilani', 'Ashoka University', 'Shiv Nadar University', 'O.P. Jindal Global University'],
    marketTrends: 'The higher education sector in India is upgrading rapidly with new-age research-focused private universities and the expansion of national institutes (IITs, IIMs, IISERs). Ph.D. degree holders with indexed journal publications (Scopus, ABDC) are highly sought after for faculty tenures and academic leadership.',
    demandDrivers: ['NEP 2020 focus on academic research over simple rote learning', 'Establishment of premier liberal arts, research, and corporate business schools', 'Stricter UGC criteria for assistant professor appointments in state and central colleges']
  },
  'phd-industrial-research': {
    outlook: 'Very High',
    hiringHubs: ['Bengaluru', 'Hyderabad', 'Pune', 'Mumbai', 'Chennai', 'Noida'],
    prominentEmployers: ['Microsoft Research India', 'Google Research India', 'NVIDIA Research', 'Biocon R&D', 'Dr. Reddy\'s Labs', 'Samsung R&D Institute', 'Tata Chemicals Innovation Centre', 'Reliance R&D'],
    marketTrends: 'Global tech and pharmaceutical giants have turned their Indian centers into core global R&D bases. Ph.D. specialists in deep learning, biotechnology, and advanced material sciences are hired to design proprietary products, file patents, and lead highly advanced corporate innovation labs.',
    demandDrivers: ['Filing patents and intellectual property creation in advanced technologies', 'Establishment of specialized AI, ML, and molecular design labs in India', 'High-value corporate collaborations with local premier research institutions']
  }
};
